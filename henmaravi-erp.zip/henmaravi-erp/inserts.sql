﻿SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO
USE HenmaraviDB;
GO

-- LIMPEZA DE DADOS (Evita erro de chave duplicada ao rodar várias vezes)
DELETE FROM logs_auditoria;
DELETE FROM ordens_servico_pecas;
DELETE FROM ordens_servico_servicos;
DELETE FROM ordens_servico;
DELETE FROM pecas_compras;
DELETE FROM compras;
DELETE FROM servicos;
DELETE FROM pecas;
DELETE FROM veiculos;
DELETE FROM mecanicos;
DELETE FROM funcionarios;
DELETE FROM clientes;
DELETE FROM pessoas;
DELETE FROM usuarios;
GO

-- 0. INSERTS DE USUARIOS DO SISTEMA (3 PERFIS DE ACESSO: ADMIN, ATENDENTE E MECANICO)
SET IDENTITY_INSERT usuarios ON;
INSERT INTO usuarios (codigo, username, password, nome_completo, email, perfil, dica_senha, ativo) VALUES
(1, 'admin', '123', 'Administrador Geral (Gerente)', 'admin@henmaravi.com', 'ADMIN', 'Sequência numérica de 1 a 3', 1),
(2, 'mecanico', '123', 'Kleber Machado (Mecânico)', 'mecanico@henmaravi.com', 'MECANICO', 'Sequência numérica de 1 a 3', 1),
(3, 'atendente', '123', 'Beatriz Silva (Operacional)', 'beatriz@henmaravi.com', 'ATENDENTE', 'Sequência numérica de 1 a 3', 1);
SET IDENTITY_INSERT usuarios OFF;
GO

-- 1. INSERTS DE PESSOAS PARA CLIENTES (IDs de 1 a 10)
SET IDENTITY_INSERT pessoas ON;
INSERT INTO pessoas (codigo, cpf, nome, telefone, cep, email) VALUES 
(1, '11111111111', 'João Silva', '(11) 99999-1111', '01001000', 'joao@email.com'),
(2, '22222222222', 'Maria Oliveira', '(11) 98888-2222', '02002000', 'maria@email.com'),
(3, '33333333333', 'Carlos Mendes', '(11) 97777-3333', '03003000', 'carlos@email.com'),
(4, '44444444444', 'Ana Souza', '(11) 96666-4444', '04004000', 'ana@email.com'),
(5, '55555555555', 'Pedro Santos', '(11) 95555-5555', '05005000', 'pedro@email.com'),
(6, '66666666666', 'Lucia Lima', '(11) 94444-6666', '06006000', 'lucia@email.com'),
(7, '77777777777', 'Roberto Costa', '(11) 93333-7777', '07007000', 'roberto@email.com'),
(8, '88888888888', 'Fernanda Gomes', '(11) 92222-8888', '08008000', 'fernanda@email.com'),
(9, '99999999999', 'Marcos Ferreira', '(11) 91111-9999', '09009000', 'marcos@email.com'),
(10, '00000000000', 'Juliana Rocha', '(11) 90000-0000', '10010000', 'juliana@email.com');
SET IDENTITY_INSERT pessoas OFF;

-- CLIENTES
INSERT INTO clientes (pessoas_codigo) VALUES 
(1), (2), (3), (4), (5), (6), (7), (8), (9), (10);

-- 2. INSERTS DE PESSOAS PARA FUNCIONARIOS (IDs de 11 a 20)
SET IDENTITY_INSERT pessoas ON;
INSERT INTO pessoas (codigo, cpf, nome, telefone, cep, email) VALUES 
(11, '12312312311', 'Armando Souza', '(11) 91234-1111', '01001001', 'armando@email.com'),
(12, '12312312322', 'Beatriz Silva', '(11) 91234-2222', '02002002', 'beatriz@email.com'),
(13, '12312312333', 'Caio Ribeiro', '(11) 91234-3333', '03003003', 'caio@email.com'),
(14, '12312312344', 'Daniel Alves', '(11) 91234-4444', '04004004', 'daniel@email.com'),
(15, '12312312355', 'Elaine Costa', '(11) 91234-5555', '05005005', 'elaine@email.com'),
(16, '12312312366', 'Fabio Junior', '(11) 91234-6666', '06006006', 'fabio@email.com'),
(17, '12312312377', 'Gabriel Lima', '(11) 91234-7777', '07007007', 'gabriel@email.com'),
(18, '12312312388', 'Helena Moraes', '(11) 91234-8888', '08008008', 'helena@email.com'),
(19, '12312312399', 'Igor Santos', '(11) 91234-9999', '09009009', 'igor@email.com'),
(20, '12312312300', 'Joana Darc', '(11) 91234-0000', '10010010', 'joana@email.com');
SET IDENTITY_INSERT pessoas OFF;

-- FUNCIONARIOS
INSERT INTO funcionarios (salario, pessoas_codigo) VALUES 
(5000.00, 11), (2000.00, 12), (2000.00, 13), (2200.00, 14), (2000.00, 15),
(3500.00, 16), (1800.00, 17), (1900.00, 18), (2500.00, 19), (1500.00, 20);

-- 3. INSERTS DE PESSOAS PARA MECANICOS (IDs de 21 a 30)
SET IDENTITY_INSERT pessoas ON;
INSERT INTO pessoas (codigo, cpf, nome, telefone, cep, email) VALUES 
(21, '32132132111', 'Kleber Machado', '(11) 93210-1111', '01001011', 'kleber@email.com'),
(22, '32132132122', 'Leandro Borges', '(11) 93210-2222', '02002022', 'leandro@email.com'),
(23, '32132132133', 'Mario Sergio', '(11) 93210-3333', '03003033', 'mario@email.com'),
(24, '32132132144', 'Norberto Silva', '(11) 93210-4444', '04004044', 'norberto@email.com'),
(25, '32132132155', 'Osvaldo Cruz', '(11) 93210-5555', '05005055', 'osvaldo@email.com'),
(26, '32132132166', 'Paulo Nunes', '(11) 93210-6666', '06006066', 'paulo@email.com'),
(27, '32132132177', 'Rafael Dias', '(11) 93210-7777', '07007077', 'rafael@email.com'),
(28, '32132132188', 'Samuel Costa', '(11) 93210-8888', '08008088', 'samuel@email.com'),
(29, '32132132199', 'Thiago Neves', '(11) 93210-9999', '09009099', 'thiago@email.com'),
(30, '32132132100', 'Ulisses Guimaraes', '(11) 93210-0000', '10010100', 'ulisses@email.com');
SET IDENTITY_INSERT pessoas OFF;

-- MECANICOS
INSERT INTO mecanicos (comissao, pessoas_codigo) VALUES 
(10.00, 21), (15.00, 22), (12.00, 23),
(10.00, 24), (20.00, 25), (15.00, 26),
(10.00, 27), (12.00, 28), (10.00, 29),
(18.00, 30);

-- 4. INSERTS VEICULOS (10 registros)
SET IDENTITY_INSERT veiculos ON;
INSERT INTO veiculos (codigo, descricao, placa, preco) VALUES 
(1, 'Honda Civic Sedan Prata', 'ABC1234', 85000.00),
(2, 'Toyota Corolla XEI Preto', 'DEF5678', 120000.00),
(3, 'Fiat Strada Freedom Branca', 'GHI9012', 90000.00),
(4, 'VW Gol 1.0 Flex Vermelho', 'JKL3456', 45000.00),
(5, 'Hyundai HB20 Comfort Azul', 'MNO7890', 70000.00),
(6, 'Jeep Renegade Sport Verde', 'PQR1234', 95000.00),
(7, 'Chevrolet Onix LT Prata', 'STU5678', 75000.00),
(8, 'Ford Ka SE Hatch Branco', 'VWX9012', 50000.00),
(9, 'Renault Logan Expression', 'YZA3456', 55000.00),
(10, 'VW Nivus Highline Cinza', 'BCD7890', 130000.00);
SET IDENTITY_INSERT veiculos OFF;

-- 5. INSERTS PECAS (10 registros)
SET IDENTITY_INSERT pecas ON;
INSERT INTO pecas (codigo, descricao, estoque, nome, numero, preco) VALUES 
(1, 'Óleo de motor para troca', 50, 'Óleo Sintético 5W30', 'OL-001', 45.90),
(2, 'Filtro para proteção', 30, 'Filtro de Óleo Bosch', 'FO-002', 25.50),
(3, 'Para freios a disco', 20, 'Pastilha de Freio', 'PF-003', 120.00),
(4, 'Amortecedor a gás', 10, 'Amortecedor Dianteiro', 'AM-004', 350.00),
(5, 'Bateria 12V selada', 15, 'Bateria Moura 60Ah', 'BA-005', 450.00),
(6, 'Vela resistiva', 100, 'Vela de Ignição NGK', 'VL-006', 20.00),
(7, 'Correia em V', 25, 'Correia Dentada Gates', 'CD-007', 85.00),
(8, 'Filtro motor', 40, 'Filtro de Ar Fram', 'FA-008', 35.00),
(9, 'Palheta de borracha', 60, 'Palheta Parabrisa', 'PL-009', 40.00),
(10, 'Lâmpada halógena', 80, 'Lâmpada H7 Philips', 'LP-010', 55.00);
SET IDENTITY_INSERT pecas OFF;

-- 6. INSERTS SERVICOS (10 registros)
SET IDENTITY_INSERT servicos ON;
INSERT INTO servicos (codigo_servico, descricao, preco) VALUES 
(1, 'Troca de Óleo e Filtro', 50.00),
(2, 'Alinhamento e Balanceamento', 120.00),
(3, 'Substituição de Pastilhas', 80.00),
(4, 'Troca de Amortecedores', 200.00),
(5, 'Limpeza de Bico Injetor', 150.00),
(6, 'Revisão Elétrica', 100.00),
(7, 'Troca de Correia Dentada', 250.00),
(8, 'Higienização de Ar Condicionado', 130.00),
(9, 'Regulagem de Farol', 40.00),
(10, 'Diagnóstico Computadorizado', 90.00);
SET IDENTITY_INSERT servicos OFF;

-- 7. INSERTS COMPRAS (10 registros)
SET IDENTITY_INSERT compras ON;
INSERT INTO compras (codigo, data_compra, valor_total, funcionarios_codigo) VALUES 
(1, '2026-06-01 10:00:00', 450.00, 11),
(2, '2026-06-01 14:30:00', 120.00, 12),
(3, '2026-06-02 09:15:00', 350.00, 13),
(4, '2026-06-02 16:45:00', 80.00, 14),
(5, '2026-06-03 11:20:00', 150.00, 15),
(6, '2026-06-03 13:10:00', 250.00, 16),
(7, '2026-06-04 10:05:00', 50.00, 17),
(8, '2026-06-04 15:50:00', 90.00, 18),
(9, '2026-06-05 08:40:00', 130.00, 19),
(10, '2026-06-05 17:00:00', 200.00, 20);
SET IDENTITY_INSERT compras OFF;

-- 8. INSERTS PECAS_COMPRAS (10 registros)
INSERT INTO pecas_compras (preco_unitario, qtd, compras_codigo, pecas_codigo) VALUES 
(45.00, 10, 1, 1),
(120.00, 1, 2, 3),
(350.00, 1, 3, 4),
(40.00, 2, 4, 9),
(15.00, 10, 5, 6),
(250.00, 1, 6, 7),
(25.00, 2, 7, 2),
(45.00, 2, 8, 1),
(130.00, 1, 9, 8),
(20.00, 10, 10, 6);

-- 9. INSERTS ORDENS_SERVICO (10 registros)
SET IDENTITY_INSERT ordens_servico ON;
INSERT INTO ordens_servico (codigo, data_abretura, status, clientes_codigo, funcionarios_codigo, mecanicos_codigo, veiculos_codigo) VALUES 
(1, '2026-06-01 08:00:00', 'Concluída', 1, 11, 21, 1),
(2, '2026-06-01 09:30:00', 'Concluída', 2, 12, 22, 2),
(3, '2026-06-02 10:15:00', 'Em Andamento', 3, 13, 23, 3),
(4, '2026-06-02 14:00:00', 'Aberta', 4, 14, 24, 4),
(5, '2026-06-03 11:45:00', 'Aguardando Peça', 5, 15, 25, 5),
(6, '2026-06-03 15:20:00', 'Em Andamento', 6, 16, 26, 6),
(7, '2026-06-04 09:10:00', 'Concluída', 7, 17, 27, 7),
(8, '2026-06-04 13:40:00', 'Aberta', 8, 18, 28, 8),
(9, '2026-06-05 10:05:00', 'Concluída', 9, 19, 29, 9),
(10, '2026-06-05 16:30:00', 'Em Andamento', 10, 20, 30, 10);
SET IDENTITY_INSERT ordens_servico OFF;

-- 10. INSERTS ORDENS_SERVICO_PECAS E SERVICOS (10 + 10)
INSERT INTO ordens_servico_pecas (preco, qtd, ordens_servico_codigo, pecas_codigo) VALUES 
(45.90, 4, 1, 1), (25.50, 1, 1, 2), (350.00, 2, 2, 4), (20.00, 4, 5, 6), (120.00, 1, 6, 3),
(45.90, 4, 7, 1), (25.50, 1, 7, 2), (85.00, 1, 4, 7), (35.00, 1, 4, 8), (450.00, 1, 3, 5);

INSERT INTO ordens_servico_servicos (preco, qtd, ordens_servico_codigo, servicos_codigo) VALUES 
(50.00, 1, 1, 1), (200.00, 1, 2, 4), (120.00, 1, 2, 2), (150.00, 1, 5, 5), (80.00, 1, 6, 3),
(50.00, 1, 7, 1), (250.00, 1, 4, 7), (130.00, 1, 8, 8), (90.00, 1, 5, 10), (100.00, 1, 3, 6);
GO
