package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "pecas_compras")
@Data
public class PecaCompra {

    @EmbeddedId
    private PecaCompraId id = new PecaCompraId();

    @ManyToOne(optional = false)
    @MapsId("compraCodigo")
    @JoinColumn(name = "compras_codigo", nullable = false)
    private Compra compra;

    @ManyToOne(optional = false)
    @MapsId("pecaCodigo")
    @JoinColumn(name = "pecas_codigo", nullable = false)
    private Peca peca;

    @Column(nullable = false)
    private Integer qtd;

    @Column(name = "preco_unitario", nullable = false, precision = 10, scale = 2)
    private BigDecimal precoUnitario;

    // Getter auxiliar para serialização JSON no front-end (evita undefined em p.pecaCodigo)
    public Integer getPecaCodigo() {
        if (peca != null && peca.getCodigo() != null) {
            return peca.getCodigo();
        }
        return id != null ? id.getPecaCodigo() : null;
    }
}
