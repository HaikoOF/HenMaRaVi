package com.henmaravi.erp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.io.Serializable;

@Embeddable
@Data
public class OrdemServicoServicoId implements Serializable {

    @Column(name = "ordens_servico_codigo")
    private Integer ordemServicoCodigo;

    @Column(name = "servicos_codigo")
    private Integer servicoCodigo;
}
