package com.henmaravi.erp.repository;

import com.henmaravi.erp.entity.LogAuditoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LogAuditoriaRepository extends JpaRepository<LogAuditoria, Integer> {
    List<LogAuditoria> findTop100ByOrderByDataEventoDesc();
    List<LogAuditoria> findByAcaoStartingWithOrderByDataEventoDesc(String prefixoAcao);
    List<LogAuditoria> findByTabelaAfetadaInOrderByDataEventoDesc(List<String> tabelas);
}
