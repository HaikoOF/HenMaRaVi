package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.*;
import com.henmaravi.erp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CompraService {

    @Autowired private CompraRepository compraRepo;
    @Autowired private PecaCompraRepository pecaCompraRepo;
    @Autowired private PecaRepository pecaRepo;

    public List<Compra> listarTodas() {
        return compraRepo.findAll();
    }

    public Optional<Compra> buscarPorId(Integer id) {
        return compraRepo.findById(id);
    }

    @Transactional
    public Compra salvar(Compra compra) {
        // Se a data de compra veio vazia, a gente joga a data e hora de agora
        if(compra.getDataCompra() == null) compra.setDataCompra(new Date());
        
        // Toda nota de compra começa zerada até a gente colocar os itens nela
        if(compra.getValorTotal() == null) compra.setValorTotal(BigDecimal.ZERO);
        
        return compraRepo.save(compra);
    }

    @Transactional
    public void excluir(Integer id) {
        // Antes de apagar a nota de compra, a gente precisa limpar as peças que tão atreladas nela
        // Lembrete: a trigger ou o service devia reverter o estoque aqui tbm, mas a exclusão limpa a base
        pecaCompraRepo.deleteAll(listarPecas(id));
        compraRepo.deleteById(id);
    }

    // -- Itens da Compra --
    public List<PecaCompra> listarPecas(Integer compraId) {
        return pecaCompraRepo.findByIdCompraCodigo(compraId);
    }

    @Transactional
    public PecaCompra adicionarPeca(Integer compraId, Integer pecaId, Integer qtd, BigDecimal precoUnitario) {
        Compra compra = compraRepo.findById(compraId).orElseThrow(() -> new RuntimeException("Eita, compra não encontrada"));
        Peca peca = pecaRepo.findById(pecaId).orElseThrow(() -> new RuntimeException("Não achei essa peça pra dar entrada"));

        // Maravilha, chegou peça nova! Só somar no estoque atual
        peca.setEstoque(peca.getEstoque() + qtd);
        pecaRepo.save(peca);

        PecaCompra item = new PecaCompra();
        item.getId().setCompraCodigo(compraId);
        item.getId().setPecaCodigo(pecaId);
        item.setCompra(compra);
        item.setPeca(peca);
        item.setQtd(qtd);
        item.setPrecoUnitario(precoUnitario);

        PecaCompra salvo = pecaCompraRepo.save(item);
        
        // Atualiza o total da compra
        atualizarTotal(compraId);
        return salvo;
    }

    @Transactional
    public void removerPeca(Integer compraId, Integer pecaId) {
        PecaCompraId id = new PecaCompraId();
        id.setCompraCodigo(compraId);
        id.setPecaCodigo(pecaId);

        pecaCompraRepo.findById(id).ifPresent(item -> {
            // Ih rapaz, cancelaram a entrada dessa peça. Tem que arrancar ela do estoque de novo.
            Peca peca = item.getPeca();
            peca.setEstoque(peca.getEstoque() - item.getQtd()); 
            pecaRepo.save(peca);
            
            // Agora sim deleta da nota fiscal
            pecaCompraRepo.delete(item);
            
            // Dá aquele refresh no total da compra
            atualizarTotal(compraId);
        });
    }

    private void atualizarTotal(Integer compraId) {
        Compra compra = compraRepo.findById(compraId).orElseThrow();
        BigDecimal total = listarPecas(compraId).stream()
                .map(p -> p.getPrecoUnitario().multiply(new BigDecimal(p.getQtd())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        compra.setValorTotal(total);
        compraRepo.save(compra);
    }
}
