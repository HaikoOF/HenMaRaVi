package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.*;
import com.henmaravi.erp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CompraService {

    @Autowired
    private CompraRepository compraRepo;
    @Autowired
    private PecaCompraRepository pecaCompraRepo;
    @Autowired
    private PecaRepository pecaRepo;
    @Autowired
    private AuditoriaService auditoriaService;

    public List<Compra> listarTodas() {
        return compraRepo.findAll();
    }

    public Optional<Compra> buscarPorId(Integer id) {
        return compraRepo.findById(id);
    }

    @Transactional
    public Compra salvar(Compra compra) {
        if (compra.getFuncionario() == null || compra.getFuncionario().getCodigo() == null) {
            throw new IllegalArgumentException("Selecione o funcionário responsável pela compra.");
        }

        if (compra.getCodigo() != null) {
            Optional<Compra> existenteOpt = compraRepo.findById(compra.getCodigo());
            if (existenteOpt.isPresent()) {
                Compra existente = existenteOpt.get();
                existente.setFuncionario(compra.getFuncionario());
                return compraRepo.save(existente);
            }
        }

        if (compra.getDataCompra() == null)
            compra.setDataCompra(new Date());
        if (compra.getValorTotal() == null)
            compra.setValorTotal(BigDecimal.ZERO);

        return compraRepo.save(compra);
    }

    @Transactional
    public void excluir(Integer id, String motivo) {
        Compra compra = compraRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Nota de Compra #" + id + " não encontrada."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        List<PecaCompra> itens = listarPecas(id);
        List<String> resumoSubtraido = new ArrayList<>();

        // Subtrai do estoque todas as peças que haviam entrado por esta compra (Item 5)
        for (PecaCompra item : itens) {
            Peca peca = item.getPeca();
            int novoEstoque = Math.max(0, peca.getEstoque() - item.getQtd());
            peca.setEstoque(novoEstoque);
            pecaRepo.save(peca);
            resumoSubtraido
                    .add("-" + item.getQtd() + " un. de " + peca.getNome() + " (Estoque atual: " + novoEstoque + ")");
        }

        pecaCompraRepo.deleteAll(itens);
        compraRepo.deleteById(id);

        String detalheItens = resumoSubtraido.isEmpty() ? "Sem itens lançados" : String.join(", ", resumoSubtraido);
        String descricaoLog = "Nota de Compra #" + id + " (Valor: R$ " + compra.getValorTotal() +
                ") excluída e estoque subtraído [" + detalheItens + "]";

        auditoriaService.registrarExclusao("compras", "EXCLUSAO_COMPRA_ESTOQUE", descricaoLog, motivoValidado);
    }

    // -- Itens da Compra --
    public List<PecaCompra> listarPecas(Integer compraId) {
        return pecaCompraRepo.findByIdCompraCodigo(compraId);
    }

    @Transactional
    public PecaCompra adicionarPeca(Integer compraId, Integer pecaId, Integer qtd, BigDecimal precoUnitario) {
        if (qtd == null || qtd <= 0) {
            throw new IllegalArgumentException("A quantidade comprada deve ser maior que zero.");
        }
        if (precoUnitario == null || precoUnitario.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("O custo unitário deve ser maior que zero.");
        }

        Compra compra = compraRepo.findById(compraId)
                .orElseThrow(() -> new IllegalArgumentException("Nota de compra #" + compraId + " não encontrada."));
        Peca peca = pecaRepo.findById(pecaId)
                .orElseThrow(() -> new IllegalArgumentException("Peça #" + pecaId + " não encontrada no catálogo."));

        peca.setEstoque(peca.getEstoque() + qtd);
        pecaRepo.save(peca);

        PecaCompraId id = new PecaCompraId();
        id.setCompraCodigo(compraId);
        id.setPecaCodigo(pecaId);

        Optional<PecaCompra> itemExistenteOpt = pecaCompraRepo.findById(id);
        PecaCompra item;
        if (itemExistenteOpt.isPresent()) {
            item = itemExistenteOpt.get();
            item.setQtd(item.getQtd() + qtd);
            item.setPrecoUnitario(precoUnitario);
        } else {
            item = new PecaCompra();
            item.setId(id);
            item.setCompra(compra);
            item.setPeca(peca);
            item.setQtd(qtd);
            item.setPrecoUnitario(precoUnitario);
        }

        PecaCompra salvo = pecaCompraRepo.save(item);
        atualizarTotal(compraId);
        return salvo;
    }

    @Transactional
    public void removerPeca(Integer compraId, Integer pecaId, String motivo) {
        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        PecaCompraId id = new PecaCompraId();
        id.setCompraCodigo(compraId);
        id.setPecaCodigo(pecaId);

        PecaCompra item = pecaCompraRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Item da compra não encontrado."));

        Peca peca = item.getPeca();
        int qtdRemovida = item.getQtd();
        int novoEstoque = Math.max(0, peca.getEstoque() - qtdRemovida);
        peca.setEstoque(novoEstoque);
        pecaRepo.save(peca);

        pecaCompraRepo.delete(item);
        atualizarTotal(compraId);

        String descricaoLog = "Item removido da Compra #" + compraId + ": -" + qtdRemovida +
                " un. da peça '" + peca.getNumero() + " - " + peca.getNome() +
                "' (Custo Unit: R$ " + item.getPrecoUnitario() + "). Estoque ajustado para " + novoEstoque + ".";

        auditoriaService.registrarExclusao("pecas_compras", "EXCLUSAO_ITEM_COMPRA", descricaoLog, motivoValidado);
    }

    private void atualizarTotal(Integer compraId) {
        Compra compra = compraRepo.findById(compraId).orElseThrow();
        BigDecimal total = listarPecas(compraId).stream()
                .map(p -> p.getPrecoUnitario().multiply(new BigDecimal(p.getQtd())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        compra.setValorTotal(total);
        compraRepo.save(compra);
    }
}
