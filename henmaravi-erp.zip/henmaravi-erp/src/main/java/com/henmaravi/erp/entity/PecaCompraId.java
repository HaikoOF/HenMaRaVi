package com.henmaravi.erp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.io.Serializable;

@Embeddable
@Data
public class PecaCompraId implements Serializable {

    @Column(name = "compras_codigo")
    private Integer compraCodigo;

    @Column(name = "pecas_codigo")
    private Integer pecaCodigo;
}
