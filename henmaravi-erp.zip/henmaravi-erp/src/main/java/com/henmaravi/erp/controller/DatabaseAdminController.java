package com.henmaravi.erp.controller;

import com.henmaravi.erp.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;

@Controller
@RequestMapping("/admin-bd")
public class DatabaseAdminController {

    @Autowired private DatabaseAdminService dbAdminService;
    @Autowired private ClienteService clienteService;
    @Autowired private FuncionarioService funcionarioService;
    @Autowired private PecaService pecaService;
    @Autowired private OrdemServicoService osService;

    @GetMapping
    public String painelAdministracaoBD(
            @RequestParam(value = "osIdFunc", required = false, defaultValue = "1") Integer osIdFunc,
            @RequestParam(value = "clienteIdFunc", required = false, defaultValue = "1") Integer clienteIdFunc,
            @RequestParam(value = "statusFunc", required = false, defaultValue = "Concluída") String statusFunc,
            Model model) {

        // 1. Dados das 3 Views Complexas
        model.addAttribute("viewResumoOS", dbAdminService.consultarViewResumoOS());
        model.addAttribute("viewDesempenhoMecanicos", dbAdminService.consultarViewDesempenhoMecanicos());
        model.addAttribute("viewAnaliseEstoque", dbAdminService.consultarViewAnaliseEstoque());

        // 2. Dados das 3 Functions (Escalar, Tabela Inline e Variável Tipo Tabela)
        model.addAttribute("osIdFunc", osIdFunc);
        model.addAttribute("resultadoFuncaoEscalar", dbAdminService.consultarFuncaoEscalarTotalOS(osIdFunc));

        model.addAttribute("clienteIdFunc", clienteIdFunc);
        model.addAttribute("resultadoFuncaoTabela", dbAdminService.consultarFuncaoTabelaOSPorCliente(clienteIdFunc));

        model.addAttribute("statusFunc", statusFunc);
        model.addAttribute("resultadoFuncaoVariavelTabela", dbAdminService.consultarFuncaoVariavelTabelaComissao(statusFunc));

        // 3. Logs de Auditoria gerados pelos 3 Triggers e Procedures
        model.addAttribute("logsAuditoria", dbAdminService.listarLogsAuditoria());

        // 4. Dados auxiliares para selects e Caminho de Backup
        model.addAttribute("clientes", clienteService.listarTodos());
        model.addAttribute("funcionarios", funcionarioService.listarTodos());
        model.addAttribute("pecas", pecaService.listarTodos());
        model.addAttribute("ordens", osService.listarTodas());
        model.addAttribute("caminhoPadraoBackup", dbAdminService.obterCaminhoPadraoBackup());

        return "pages/admin-bd/index";
    }

    // --- Execução das 3 Stored Procedures ---

    @PostMapping("/procedure/finalizar-os")
    public String executarSpFinalizarOS(@RequestParam("osCodigo") Integer osCodigo, RedirectAttributes ra) {
        try {
            dbAdminService.executarProcedureFinalizarOS(osCodigo);
            ra.addFlashAttribute("sucesso", "Procedure sp_FinalizarOrdemServico executada com sucesso para a O.S. #" + osCodigo + "!");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Erro ao executar sp_FinalizarOrdemServico: " + e.getMessage());
        }
        return "redirect:/admin-bd";
    }

    @PostMapping("/procedure/reajustar-precos")
    public String executarSpReajustarPrecos(@RequestParam("percentual") BigDecimal percentual, RedirectAttributes ra) {
        try {
            dbAdminService.executarProcedureReajustarPrecos(percentual);
            ra.addFlashAttribute("sucesso", "Procedure sp_ReajustarPrecoPecas executada com sucesso (" + percentual + "%)!");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Erro ao executar sp_ReajustarPrecoPecas: " + e.getMessage());
        }
        return "redirect:/admin-bd";
    }

    @PostMapping("/procedure/compra-rapida")
    public String executarSpCompraRapida(@RequestParam("funcionarioCodigo") Integer funcionarioCodigo,
                                         @RequestParam("pecaCodigo") Integer pecaCodigo,
                                         @RequestParam("qtd") Integer qtd,
                                         @RequestParam("precoUnitario") BigDecimal precoUnitario,
                                         RedirectAttributes ra) {
        try {
            dbAdminService.executarProcedureCompraRapida(funcionarioCodigo, pecaCodigo, qtd, precoUnitario);
            ra.addFlashAttribute("sucesso", "Procedure sp_RegistrarCompraRapida executada com sucesso! Estoque e Nota Fiscal atualizados.");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Erro ao executar sp_RegistrarCompraRapida: " + e.getMessage());
        }
        return "redirect:/admin-bd";
    }

    // --- Execução de Backup e Restore (Item 5.3 - Ponto Extra) ---

    @PostMapping("/backup")
    public String executarBackup(@RequestParam(value = "caminhoArquivo", required = false) String caminhoArquivo,
                                 RedirectAttributes ra) {
        try {
            String arquivoGerado = dbAdminService.realizarBackup(caminhoArquivo);
            ra.addFlashAttribute("sucesso", "BACKUP concluído com sucesso! Arquivo salvo em: " + arquivoGerado);
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Falha ao realizar Backup: " + e.getMessage());
        }
        return "redirect:/admin-bd";
    }

    @PostMapping("/restore")
    public String executarRestore(@RequestParam(value = "caminhoArquivo", required = false) String caminhoArquivo,
                                  RedirectAttributes ra) {
        try {
            String arquivoRestaurado = dbAdminService.realizarRestore(caminhoArquivo);
            ra.addFlashAttribute("sucesso", "RESTORE concluído com sucesso a partir de: " + arquivoRestaurado + "! Banco HenmaraviDB restaurado.");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Falha ao realizar Restore: " + e.getMessage());
        }
        return "redirect:/admin-bd";
    }
}
