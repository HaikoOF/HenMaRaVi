package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Table(name = "ordens_servico")
@Data
public class OrdemServico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;

    @Column(name = "data_abretura", columnDefinition = "DATETIME default getdate()")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAbertura;

    @Column(nullable = false, length = 50, columnDefinition = "varchar(50) default 'Aberta'")
    private String status;

    @ManyToOne(optional = false)
    @JoinColumn(name = "clientes_codigo", nullable = false)
    private Cliente cliente;

    @ManyToOne(optional = false)
    @JoinColumn(name = "funcionarios_codigo", nullable = false)
    private Funcionario funcionario;

    @ManyToOne(optional = false)
    @JoinColumn(name = "mecanicos_codigo", nullable = false)
    private Mecanico mecanico;

    @ManyToOne(optional = false)
    @JoinColumn(name = "veiculos_codigo", nullable = false)
    private Veiculo veiculo;
}
