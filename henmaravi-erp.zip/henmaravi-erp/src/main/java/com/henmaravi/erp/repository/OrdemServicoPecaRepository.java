package com.henmaravi.erp.repository;

import com.henmaravi.erp.entity.OrdemServicoPeca;
import com.henmaravi.erp.entity.OrdemServicoPecaId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrdemServicoPecaRepository extends JpaRepository<OrdemServicoPeca, OrdemServicoPecaId> {
    List<OrdemServicoPeca> findByIdOrdemServicoCodigo(Integer osId);
}
