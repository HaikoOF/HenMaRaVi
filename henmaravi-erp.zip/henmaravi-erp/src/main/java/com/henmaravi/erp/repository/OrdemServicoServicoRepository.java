package com.henmaravi.erp.repository;

import com.henmaravi.erp.entity.OrdemServicoServico;
import com.henmaravi.erp.entity.OrdemServicoServicoId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrdemServicoServicoRepository extends JpaRepository<OrdemServicoServico, OrdemServicoServicoId> {
    List<OrdemServicoServico> findByIdOrdemServicoCodigo(Integer osId);
}
