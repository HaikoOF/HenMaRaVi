package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "usuarios")
@Data
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;

    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false, length = 255)
    private String password;

    @Column(name = "nome_completo", nullable = false, length = 150)
    private String nomeCompleto;

    @Column(nullable = false, unique = true, length = 320)
    private String email;

    @Column(nullable = false, length = 30)
    private String perfil = "MECANICO"; // ADMIN ou MECANICO

    @Column(name = "dica_senha", length = 255)
    private String dicaSenha;

    @Column(nullable = false)
    private Boolean ativo = true;
}

