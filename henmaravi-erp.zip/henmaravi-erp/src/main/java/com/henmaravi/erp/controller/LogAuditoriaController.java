package com.henmaravi.erp.controller;

import com.henmaravi.erp.service.AuditoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LogAuditoriaController {

    @Autowired
    private AuditoriaService auditoriaService;

    @GetMapping("/logs")
    public String index(Model model) {
        model.addAttribute("logsExclusao", auditoriaService.listarLogsExclusao());
        model.addAttribute("logsComprasEstoque", auditoriaService.listarLogsComprasEstoque());
        model.addAttribute("todosLogs", auditoriaService.listarTodosLogs());
        return "pages/logs/index";
    }
}

