package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Peca;
import com.henmaravi.erp.service.PecaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class PecaController {

    @Autowired
    private PecaService pecaService;

    @GetMapping("/estoque")
    public String index(Model model) {
        model.addAttribute("pecas", pecaService.listarTodos());
        return "pages/pecas/index";
    }

    @GetMapping("/api/pecas")
    @ResponseBody
    public List<Peca> listarAPI() {
        return pecaService.listarTodos();
    }

    @GetMapping("/api/pecas/{id}")
    @ResponseBody
    public ResponseEntity<Peca> buscarPorId(@PathVariable Integer id) {
        return pecaService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/pecas")
    @ResponseBody
    public Peca salvar(@RequestBody Peca peca) {
        if (peca.getEstoque() == null)
            peca.setEstoque(0);
        return pecaService.salvar(peca);
    }

    @PutMapping("/api/pecas/{id}")
    @ResponseBody
    public ResponseEntity<Peca> atualizar(@PathVariable Integer id, @RequestBody Peca peca) {
        if (pecaService.buscarPorId(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        peca.setCodigo(id);
        return ResponseEntity.ok(pecaService.salvar(peca));
    }

    @DeleteMapping("/api/pecas/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(
            @PathVariable Integer id,
            @RequestParam(value = "motivo", required = false) String motivo,
            @RequestParam(value = "forcar", required = false, defaultValue = "false") boolean forcar) {
        pecaService.excluir(id, motivo, forcar);
        return ResponseEntity.noContent().build();
    }
}
