package com.henmaravi.erp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        final BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
        return new PasswordEncoder() {
            @Override
            public String encode(CharSequence rawPassword) {
                return rawPassword.toString();
            }

            @Override
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
                if (encodedPassword == null || rawPassword == null) {
                    return false;
                }
                if (encodedPassword.startsWith("$2a$") || encodedPassword.startsWith("$2b$")) {
                    return bcrypt.matches(rawPassword, encodedPassword);
                }
                return encodedPassword.equals(rawPassword.toString());
            }
        };
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                // Recursos públicos e recuperação de senha
                .requestMatchers("/css/**", "/js/**", "/images/**", "/lembrete-senha", "/redefinir-senha").permitAll()

                // 1. Módulos exclusivos do ADMIN (Gerente)
                // - Gestão de Contas (/usuarios)
                // - Folha de Funcionários (/funcionarios)
                // - Gestão de Mecânicos (/mecanicos)
                // - Entrada de Estoque / Compras (/compras)
                // - Logs de Exclusão e Auditoria (/logs)
                // - Administração do Banco de Dados (/admin-bd)
                .requestMatchers("/usuarios/**", "/api/usuarios/**").hasRole("ADMIN")
                .requestMatchers("/funcionarios/**", "/api/funcionarios/**").hasRole("ADMIN")
                .requestMatchers("/mecanicos/**", "/api/mecanicos/**").hasRole("ADMIN")
                .requestMatchers("/compras/**", "/api/compras/**").hasRole("ADMIN")
                .requestMatchers("/admin-bd/**", "/logs/**").hasRole("ADMIN")

                // 2. Gestão (Criar/Editar/Excluir) de Estoque de Peças e Catálogo de Serviços: SOMENTE ADMIN
                .requestMatchers(HttpMethod.POST, "/api/pecas/**", "/api/servicos/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/pecas/**", "/api/servicos/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/pecas/**", "/api/servicos/**").hasRole("ADMIN")

                // 3. Consulta de Estoque de Peças: ADMIN e ATENDENTE (Mecânico não gerencia nem acessa aba de estoque - Item 10)
                .requestMatchers("/estoque/**").hasAnyRole("ADMIN", "ATENDENTE")
                .requestMatchers(HttpMethod.GET, "/api/pecas/**", "/api/servicos/**", "/servicos/**").hasAnyRole("ADMIN", "ATENDENTE", "MECANICO")

                // 4. Clientes:
                // - Exclusão e Edição de Clientes: somente ADMIN (Item 10)
                // - Cadastro e Consulta de Clientes: ADMIN e ATENDENTE (Item 9) — Mecânico bloqueado (Item 10)
                .requestMatchers(HttpMethod.DELETE, "/api/clientes/**").hasRole("ADMIN")
                .requestMatchers("/clientes/**", "/api/clientes/**").hasAnyRole("ADMIN", "ATENDENTE")

                // 5. Veículos:
                // - Exclusão de Veículos: somente ADMIN
                // - Cadastro e Consulta de Veículos: ADMIN e ATENDENTE (Item 9)
                .requestMatchers(HttpMethod.DELETE, "/api/veiculos/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/veiculos/**").hasAnyRole("ADMIN", "ATENDENTE")
                .requestMatchers(HttpMethod.PUT, "/api/veiculos/**").hasAnyRole("ADMIN", "ATENDENTE")
                .requestMatchers("/veiculos/**", "/api/veiculos/**").hasAnyRole("ADMIN", "ATENDENTE", "MECANICO")

                // 6. Ordens de Serviço, Dashboard e Perfil: acessíveis a ADMIN, ATENDENTE e MECANICO
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/dashboard", true)
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            )
            .exceptionHandling(ex -> ex
                .accessDeniedPage("/acesso-negado")
            );
        return http.build();
    }
}
