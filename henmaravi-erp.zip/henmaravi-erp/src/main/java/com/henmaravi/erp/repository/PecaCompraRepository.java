package com.henmaravi.erp.repository;

import com.henmaravi.erp.entity.PecaCompra;
import com.henmaravi.erp.entity.PecaCompraId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PecaCompraRepository extends JpaRepository<PecaCompra, PecaCompraId> {
    List<PecaCompra> findByIdCompraCodigo(Integer compraId);
}
