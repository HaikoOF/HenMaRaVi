package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Cliente;
import com.henmaravi.erp.entity.Pessoa;
import com.henmaravi.erp.repository.ClienteRepository;
import com.henmaravi.erp.repository.PessoaRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClienteService {

    @Autowired private ClienteRepository clienteRepository;
    @Autowired private PessoaRepository pessoaRepository;
    @Autowired private JdbcTemplate jdbcTemplate;
    @Autowired private AuditoriaService auditoriaService;
    @Autowired private OrdemServicoService osService;

    @PersistenceContext
    private EntityManager entityManager;

    public List<Cliente> listarTodos() {
        return clienteRepository.findAll();
    }

    public Optional<Cliente> buscarPorId(Integer id) {
        return clienteRepository.findById(id);
    }

    @Transactional
    public Cliente salvar(Cliente dados) {
        validarENormalizarPessoa(dados);

        // Caso 1: Edição de um Cliente já existente
        if (dados.getCodigo() != null) {
            Cliente existente = clienteRepository.findById(dados.getCodigo())
                    .orElseThrow(() -> new IllegalArgumentException("Cliente #" + dados.getCodigo() + " não encontrado."));

            verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), existente.getCodigo());

            existente.setNome(dados.getNome());
            existente.setCpf(dados.getCpf());
            if (dados.getTelefone() != null) existente.setTelefone(dados.getTelefone());
            if (dados.getCep() != null) existente.setCep(dados.getCep());
            existente.setEmail(dados.getEmail());
            return clienteRepository.save(existente);
        }

        // Caso 2: Novo Cliente — Verificar se o CPF já existe na tabela pessoas (Item 8: Reusar Pessoa)
        Optional<Pessoa> pessoaExistenteOpt = pessoaRepository.findByCpf(dados.getCpf());
        if (pessoaExistenteOpt.isPresent()) {
            Pessoa p = pessoaExistenteOpt.get();
            if (clienteRepository.existsById(p.getCodigo())) {
                throw new IllegalArgumentException("Já existe um Cliente cadastrado com o CPF " + dados.getCpf() + " (" + p.getNome() + ").");
            }
            verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), p.getCodigo());

            // Atualiza dados básicos da pessoa e insere apenas a chave primária na tabela clientes
            jdbcTemplate.update(
                    "UPDATE pessoas SET nome = ?, telefone = COALESCE(?, telefone), cep = COALESCE(?, cep), email = COALESCE(?, email) WHERE codigo = ?",
                    dados.getNome(), dados.getTelefone(), dados.getCep(), dados.getEmail(), p.getCodigo()
            );
            jdbcTemplate.update("INSERT INTO clientes (pessoas_codigo) VALUES (?)", p.getCodigo());
            entityManager.flush();
            entityManager.clear();
            return clienteRepository.findById(p.getCodigo()).orElseThrow();
        }

        verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), null);
        return clienteRepository.save(dados);
    }

    @Transactional
    public void excluir(Integer id, String motivo, boolean forcar) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Cliente #" + id + " não encontrado."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        List<Integer> osVinculadas = jdbcTemplate.queryForList(
                "SELECT codigo FROM ordens_servico WHERE clientes_codigo = ?", Integer.class, id
        );

        if (!osVinculadas.isEmpty()) {
            if (!forcar) {
                String listaOs = osVinculadas.stream().map(n -> "#" + n).collect(Collectors.joining(", "));
                throw new IllegalArgumentException(
                        "Não é possível excluir o cliente '" + cliente.getNome() + "' pois ele está vinculado à(s) Ordem(ns) de Serviço " + listaOs +
                        ". Exclua a O.S. primeiro ou marque a opção 'Forçar exclusão removendo vínculos'."
                );
            }
            for (Integer osId : osVinculadas) {
                osService.excluir(osId, "Exclusão em cascata do Cliente #" + id + ": " + motivoValidado);
            }
        }

        String descricaoLog = "Cliente #" + cliente.getCodigo() + " - " + cliente.getNome() + " (CPF: " + cliente.getCpf() + ")";

        // Verifica se esta mesma Pessoa também é Mecânico ou Funcionário (Item 8)
        int outrosPapelCount = obterContagemOutrosPapeis(id, "clientes");
        if (outrosPapelCount > 0) {
            jdbcTemplate.update("DELETE FROM clientes WHERE pessoas_codigo = ?", id);
            entityManager.flush();
            entityManager.clear();
        } else {
            jdbcTemplate.update("DELETE FROM clientes WHERE pessoas_codigo = ?", id);
            jdbcTemplate.update("DELETE FROM pessoas WHERE codigo = ?", id);
            entityManager.flush();
            entityManager.clear();
        }

        auditoriaService.registrarExclusao("clientes", "EXCLUSAO_CLIENTE", descricaoLog, motivoValidado);
    }

    private void validarENormalizarPessoa(Pessoa p) {
        if (p.getNome() == null || p.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome completo é obrigatório.");
        }
        p.setNome(p.getNome().trim());

        String cpfLimpo = p.getCpf() != null ? p.getCpf().replaceAll("\\D", "") : "";
        if (cpfLimpo.length() != 11) {
            throw new IllegalArgumentException("O CPF deve conter exatamente 11 dígitos numéricos.");
        }
        p.setCpf(cpfLimpo);

        if (p.getCep() != null) {
            String cepLimpo = p.getCep().replaceAll("\\D", "");
            p.setCep(cepLimpo.isEmpty() ? null : (cepLimpo.length() > 8 ? cepLimpo.substring(0, 8) : cepLimpo));
        }

        if (p.getEmail() != null) {
            String emailTrim = p.getEmail().trim();
            p.setEmail(emailTrim.isEmpty() ? null : emailTrim);
        }

        if (p.getTelefone() != null) {
            String telTrim = p.getTelefone().trim();
            p.setTelefone(telTrim.isEmpty() ? null : telTrim);
        }
    }

    private void verificarConflitoCpfEmail(String cpf, String email, Integer ignorarCodigo) {
        pessoaRepository.findByCpf(cpf).ifPresent(p -> {
            if (ignorarCodigo == null || !p.getCodigo().equals(ignorarCodigo)) {
                throw new IllegalArgumentException("O CPF " + cpf + " já pertence a outro cadastro (" + p.getNome() + ").");
            }
        });
        if (email != null && !email.isBlank()) {
            pessoaRepository.findByEmail(email).ifPresent(p -> {
                if (ignorarCodigo == null || !p.getCodigo().equals(ignorarCodigo)) {
                    throw new IllegalArgumentException("O e-mail '" + email + "' já está cadastrado para " + p.getNome() + ".");
                }
            });
        }
    }

    private int obterContagemOutrosPapeis(Integer pessoaCodigo, String tabelaIgnorar) {
        int total = 0;
        if (!"clientes".equals(tabelaIgnorar)) {
            Integer c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM clientes WHERE pessoas_codigo = ?", Integer.class, pessoaCodigo);
            total += (c != null ? c : 0);
        }
        if (!"funcionarios".equals(tabelaIgnorar)) {
            Integer f = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM funcionarios WHERE pessoas_codigo = ?", Integer.class, pessoaCodigo);
            total += (f != null ? f : 0);
        }
        if (!"mecanicos".equals(tabelaIgnorar)) {
            Integer m = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM mecanicos WHERE pessoas_codigo = ?", Integer.class, pessoaCodigo);
            total += (m != null ? m : 0);
        }
        return total;
    }
}
