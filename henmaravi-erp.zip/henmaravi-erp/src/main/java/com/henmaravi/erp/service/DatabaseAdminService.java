package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.LogAuditoria;
import com.henmaravi.erp.repository.LogAuditoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
public class DatabaseAdminService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private LogAuditoriaRepository logRepo;

    // =====================================================
    // 1. CONSULTAS ÀS 3 VIEWS COMPLEXAS (Item 5.2)
    // =====================================================

    public List<Map<String, Object>> consultarViewResumoOS() {
        return jdbcTemplate.queryForList("SELECT * FROM vw_ResumoOrdensServico ORDER BY os_codigo DESC");
    }

    public List<Map<String, Object>> consultarViewDesempenhoMecanicos() {
        return jdbcTemplate.queryForList("SELECT * FROM vw_DesempenhoMecanicos ORDER BY receita_servicos_gerada DESC");
    }

    public List<Map<String, Object>> consultarViewAnaliseEstoque() {
        return jdbcTemplate.queryForList("SELECT * FROM vw_AnaliseEstoquePecas ORDER BY estoque_atual ASC");
    }

    // =====================================================
    // 2. CHAMADA ÀS 3 STORED PROCEDURES (Item 5.2)
    // =====================================================

    public void executarProcedureFinalizarOS(Integer osCodigo) {
        jdbcTemplate.update("EXEC sp_FinalizarOrdemServico @os_codigo = ?", osCodigo);
    }

    public void executarProcedureReajustarPrecos(BigDecimal percentual) {
        jdbcTemplate.update("EXEC sp_ReajustarPrecoPecas @percentual = ?", percentual);
    }

    public void executarProcedureCompraRapida(Integer funcionarioCodigo, Integer pecaCodigo, Integer qtd, BigDecimal precoUnitario) {
        jdbcTemplate.update(
                "EXEC sp_RegistrarCompraRapida @funcionario_codigo = ?, @peca_codigo = ?, @qtd = ?, @preco_unitario = ?",
                funcionarioCodigo, pecaCodigo, qtd, precoUnitario
        );
    }

    // =====================================================
    // 3. CHAMADA ÀS 3 FUNCTIONS (Escalar, Tabela e Variável Tabela)
    // =====================================================

    /**
     * Function 1 (Escalar): Retorna uma variável DECIMAL(10,2) com o valor total da O.S.
     */
    public BigDecimal consultarFuncaoEscalarTotalOS(Integer osCodigo) {
        BigDecimal total = jdbcTemplate.queryForObject(
                "SELECT dbo.fn_CalcularTotalOS(?)",
                BigDecimal.class,
                osCodigo
        );
        return total != null ? total : BigDecimal.ZERO;
    }

    /**
     * Function 2 (Inline Table-Valued): Retorna uma Tabela com o histórico de O.S. de um Cliente.
     */
    public List<Map<String, Object>> consultarFuncaoTabelaOSPorCliente(Integer clienteCodigo) {
        return jdbcTemplate.queryForList(
                "SELECT * FROM dbo.fn_BuscarOSPorCliente(?) ORDER BY os_codigo DESC",
                clienteCodigo
        );
    }

    /**
     * Function 3 (Multi-Statement Table-Valued): Retorna uma Variável Tipo Tabela (@TabelaComissao)
     * filtrada pelo status das Ordens de Serviço.
     */
    public List<Map<String, Object>> consultarFuncaoVariavelTabelaComissao(String status) {
        return jdbcTemplate.queryForList(
                "SELECT * FROM dbo.fn_RelatorioComissaoPorStatus(?) ORDER BY comissao_calculada DESC",
                status
        );
    }

    // =====================================================
    // 4. LOGS DE AUDITORIA DISPARADOS POR TRIGGERS
    // =====================================================

    public List<LogAuditoria> listarLogsAuditoria() {
        return logRepo.findTop100ByOrderByDataEventoDesc();
    }

    // =====================================================
    // 5. BACKUP E RESTORE DO BANCO DE DADOS (Item 5.3 - Bônus)
    // =====================================================

    public String obterCaminhoPadraoBackup() {
        try {
            String dir = jdbcTemplate.queryForObject(
                    "SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS VARCHAR(255))",
                    String.class
            );
            if (dir != null && !dir.isBlank()) {
                if (!dir.endsWith("\\") && !dir.endsWith("/")) {
                    dir += File.separator;
                }
                return dir + "HenmaraviDB_Backup.bak";
            }
        } catch (Exception ignored) {
        }
        return "C:\\Temp\\HenmaraviDB_Backup.bak";
    }

    public String realizarBackup(String caminhoArquivo) {
        String destino = (caminhoArquivo == null || caminhoArquivo.isBlank())
                ? obterCaminhoPadraoBackup()
                : caminhoArquivo.trim();

        String sql = "BACKUP DATABASE HenmaraviDB TO DISK = ? WITH FORMAT, INIT, NAME = 'HenmaraviDB - Full Backup via Sistema Java'";
        jdbcTemplate.update(sql, destino);

        jdbcTemplate.update(
                "INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao) VALUES (GETDATE(), 'HenmaraviDB', 'BACKUP', ?)",
                "Backup completo realizado via Java em: " + destino
        );
        return destino;
    }

    public String realizarRestore(String caminhoArquivo) {
        String origem = (caminhoArquivo == null || caminhoArquivo.isBlank())
                ? obterCaminhoPadraoBackup()
                : caminhoArquivo.trim();

        File f = new File(origem);
        if (!f.exists()) {
            throw new RuntimeException("Arquivo de backup (.bak) não encontrado em: " + origem + ". Realize um Backup antes de restaurar.");
        }

        String escapedPath = origem.replace("'", "''");
        String sqlRestore =
                "USE master; " +
                "ALTER DATABASE HenmaraviDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE; " +
                "RESTORE DATABASE HenmaraviDB FROM DISK = N'" + escapedPath + "' WITH REPLACE; " +
                "ALTER DATABASE HenmaraviDB SET MULTI_USER; " +
                "USE HenmaraviDB;";

        jdbcTemplate.execute(sqlRestore);
        return origem;
    }
}

