package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.*;
import com.henmaravi.erp.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
public class OrdemServicoController {

    @Autowired private OrdemServicoService osService;
    @Autowired private ClienteService clienteService;
    @Autowired private FuncionarioService funcionarioService;
    @Autowired private MecanicoService mecanicoService;
    @Autowired private VeiculoService veiculoService;
    @Autowired private PecaService pecaService;
    @Autowired private ServicoService servicoService;

    @GetMapping("/ordens-servico")
    public String index(Model model) {
        model.addAttribute("ordens", osService.listarTodas());
        return "pages/ordens/index";
    }

    @GetMapping("/ordens-servico/nova")
    public String nova(Model model) {
        model.addAttribute("clientes", clienteService.listarTodos());
        model.addAttribute("funcionarios", funcionarioService.listarTodos());
        model.addAttribute("mecanicos", mecanicoService.listarTodos());
        model.addAttribute("veiculos", veiculoService.listarTodos());
        return "pages/ordens/form";
    }

    @GetMapping("/ordens-servico/{id}/editar")
    public String editar(@PathVariable Integer id, Model model) {
        model.addAttribute("os", osService.buscarPorId(id).orElseThrow());
        model.addAttribute("clientes", clienteService.listarTodos());
        model.addAttribute("funcionarios", funcionarioService.listarTodos());
        model.addAttribute("mecanicos", mecanicoService.listarTodos());
        model.addAttribute("veiculos", veiculoService.listarTodos());
        model.addAttribute("pecasCatalogo", pecaService.listarTodos());
        model.addAttribute("servicosCatalogo", servicoService.listarTodos());
        return "pages/ordens/form";
    }

    @PostMapping("/api/ordens-servico")
    @ResponseBody
    public OrdemServico salvar(@RequestBody OrdemServico os) {
        return osService.salvar(os);
    }

    @DeleteMapping("/api/ordens-servico/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(
            @PathVariable Integer id,
            @RequestParam(value = "motivo", required = false) String motivo) {
        osService.excluir(id, motivo);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/ordens-servico/{id}/totais")
    @ResponseBody
    public Map<String, Object> totais(@PathVariable Integer id) {
        return Map.of("total", osService.calcularTotal(id));
    }

    @GetMapping("/api/ordens-servico/{id}/pecas")
    @ResponseBody
    public List<OrdemServicoPeca> listarPecas(@PathVariable Integer id) {
        return osService.listarPecas(id);
    }

    @PostMapping("/api/ordens-servico/{id}/pecas")
    @ResponseBody
    public ResponseEntity<?> addPeca(@PathVariable Integer id, @RequestBody Map<String, Integer> payload) {
        return ResponseEntity.ok(osService.adicionarPeca(id, payload.get("pecaId"), payload.get("qtd")));
    }

    @DeleteMapping("/api/ordens-servico/{id}/pecas/{pecaId}")
    @ResponseBody
    public ResponseEntity<Void> removePeca(
            @PathVariable Integer id,
            @PathVariable Integer pecaId,
            @RequestParam(value = "motivo", required = false) String motivo) {
        osService.removerPeca(id, pecaId, motivo);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/ordens-servico/{id}/servicos")
    @ResponseBody
    public List<OrdemServicoServico> listarServicos(@PathVariable Integer id) {
        return osService.listarServicos(id);
    }

    @PostMapping("/api/ordens-servico/{id}/servicos")
    @ResponseBody
    public ResponseEntity<?> addServico(@PathVariable Integer id, @RequestBody Map<String, Integer> payload) {
        return ResponseEntity.ok(osService.adicionarServico(id, payload.get("servicoId"), payload.get("qtd")));
    }

    @DeleteMapping("/api/ordens-servico/{id}/servicos/{servicoId}")
    @ResponseBody
    public ResponseEntity<Void> removeServico(
            @PathVariable Integer id,
            @PathVariable Integer servicoId,
            @RequestParam(value = "motivo", required = false) String motivo) {
        osService.removerServico(id, servicoId, motivo);
        return ResponseEntity.noContent().build();
    }
}
