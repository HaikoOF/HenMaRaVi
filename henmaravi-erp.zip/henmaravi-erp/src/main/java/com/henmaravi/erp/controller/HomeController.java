package com.henmaravi.erp.controller;

import com.henmaravi.erp.repository.ClienteRepository;
import com.henmaravi.erp.entity.OrdemServico;
import com.henmaravi.erp.service.OrdemServicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class HomeController {

    @Autowired private ClienteRepository clienteRepo;
    @Autowired private OrdemServicoService osService;

    @GetMapping("/")
    public String root() {
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        long totalClientes = clienteRepo.count();
        
        List<OrdemServico> todasOs = osService.listarTodas();
        long ordensAbertas = todasOs.stream()
            .filter(os -> !"Concluída".equals(os.getStatus()) && !"Cancelada".equals(os.getStatus()))
            .count();

        BigDecimal faturamentoTotal = todasOs.stream()
            .filter(os -> "Concluída".equals(os.getStatus()))
            .map(os -> osService.calcularTotal(os.getCodigo()))
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        List<OrdemServico> recentes = todasOs.stream()
            .sorted((a,b) -> b.getCodigo().compareTo(a.getCodigo()))
            .limit(5)
            .toList();

        model.addAttribute("totalClientes", totalClientes);
        model.addAttribute("ordensAbertas", ordensAbertas);
        model.addAttribute("faturamentoTotal", faturamentoTotal);
        model.addAttribute("recentes", recentes);

        return "pages/dashboard";
    }
}
