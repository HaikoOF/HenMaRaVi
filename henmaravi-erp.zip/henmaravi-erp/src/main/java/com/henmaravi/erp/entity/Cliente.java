package com.henmaravi.erp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "clientes")
@PrimaryKeyJoinColumn(name = "pessoas_codigo")
@Data
@EqualsAndHashCode(callSuper = true)
public class Cliente extends Pessoa {
}
