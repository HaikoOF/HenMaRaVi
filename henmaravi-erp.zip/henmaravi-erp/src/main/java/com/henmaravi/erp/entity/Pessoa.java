package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "pessoas")
@Inheritance(strategy = InheritanceType.JOINED)
@Data
public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(nullable = false, unique = true, length = 11)
    private String cpf;

    @Column(length = 8)
    private String cep;

    @Column(unique = true, length = 320)
    private String email;

    @Column(length = 20)
    private String telefone;
}
