package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "compras")
@Data
public class Compra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;

    @Column(name = "data_compra", columnDefinition = "DATETIME DEFAULT getdate()")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCompra;

    @Column(name = "valor_total", nullable = false, precision = 10, scale = 2)
    private BigDecimal valorTotal;

    @ManyToOne(optional = false)
    @JoinColumn(name = "funcionarios_codigo", nullable = false)
    private Funcionario funcionario;
}
