package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Servico;
import com.henmaravi.erp.service.ServicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ServicoController {

    @Autowired
    private ServicoService servicoService;

    @GetMapping("/servicos")
    public String index(Model model) {
        model.addAttribute("servicos", servicoService.listarTodos());
        return "pages/servicos/index";
    }

    @GetMapping("/api/servicos")
    @ResponseBody
    public List<Servico> listarAPI() {
        return servicoService.listarTodos();
    }

    @GetMapping("/api/servicos/{id}")
    @ResponseBody
    public ResponseEntity<Servico> buscarPorId(@PathVariable Integer id) {
        return servicoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/servicos")
    @ResponseBody
    public Servico salvar(@RequestBody Servico servico) {
        return servicoService.salvar(servico);
    }

    @PutMapping("/api/servicos/{id}")
    @ResponseBody
    public ResponseEntity<Servico> atualizar(@PathVariable Integer id, @RequestBody Servico servico) {
        if (!servicoService.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        servico.setCodigo(id);
        return ResponseEntity.ok(servicoService.salvar(servico));
    }

    @DeleteMapping("/api/servicos/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(@PathVariable Integer id) {
        if (!servicoService.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        servicoService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
