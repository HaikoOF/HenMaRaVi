package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Mecanico;
import com.henmaravi.erp.repository.MecanicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MecanicoService {

    @Autowired
    private MecanicoRepository repository;

    public List<Mecanico> listarTodos() {
        return repository.findAll();
    }

    public Optional<Mecanico> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public Mecanico salvar(Mecanico entity) {
        return repository.save(entity);
    }

    public void excluir(Integer id) {
        repository.deleteById(id);
    }
}
