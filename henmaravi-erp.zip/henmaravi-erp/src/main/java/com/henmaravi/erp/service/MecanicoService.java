package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Mecanico;
import com.henmaravi.erp.entity.Pessoa;
import com.henmaravi.erp.repository.MecanicoRepository;
import com.henmaravi.erp.repository.PessoaRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MecanicoService {

    @Autowired
    private MecanicoRepository repository;
    @Autowired
    private PessoaRepository pessoaRepository;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private AuditoriaService auditoriaService;
    @Autowired
    private OrdemServicoService osService;

    @PersistenceContext
    private EntityManager entityManager;

    public List<Mecanico> listarTodos() {
        return repository.findAll();
    }

    public Optional<Mecanico> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    @Transactional
    public Mecanico salvar(Mecanico dados) {
        validarENormalizar(dados);

        // Caso 1: Edição de Mecânico existente
        if (dados.getCodigo() != null) {
            Mecanico existente = repository.findById(dados.getCodigo())
                    .orElseThrow(
                            () -> new IllegalArgumentException("Mecânico #" + dados.getCodigo() + " não encontrado."));

            verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), existente.getCodigo());

            existente.setNome(dados.getNome());
            existente.setCpf(dados.getCpf());
            if (dados.getTelefone() != null)
                existente.setTelefone(dados.getTelefone());
            if (dados.getCep() != null)
                existente.setCep(dados.getCep());
            if (dados.getEmail() != null)
                existente.setEmail(dados.getEmail());
            existente.setComissao(dados.getComissao());
            return repository.save(existente);
        }

        // Caso 2: Novo Mecânico — Reusar Pessoa caso CPF já exista (Item 8)
        Optional<Pessoa> pessoaExistenteOpt = pessoaRepository.findByCpf(dados.getCpf());
        if (pessoaExistenteOpt.isPresent()) {
            Pessoa p = pessoaExistenteOpt.get();
            if (repository.existsById(p.getCodigo())) {
                throw new IllegalArgumentException(
                        "Já existe um Mecânico cadastrado com o CPF " + dados.getCpf() + " (" + p.getNome() + ").");
            }
            verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), p.getCodigo());

            jdbcTemplate.update(
                    "UPDATE pessoas SET nome = ?, telefone = COALESCE(?, telefone), cep = COALESCE(?, cep), email = COALESCE(?, email) WHERE codigo = ?",
                    dados.getNome(), dados.getTelefone(), dados.getCep(), dados.getEmail(), p.getCodigo());
            jdbcTemplate.update(
                    "INSERT INTO mecanicos (pessoas_codigo, comissao) VALUES (?, ?)",
                    p.getCodigo(), dados.getComissao());
            entityManager.flush();
            entityManager.clear();
            return repository.findById(p.getCodigo()).orElseThrow();
        }

        verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), null);
        return repository.save(dados);
    }

    @Transactional
    public void excluir(Integer id, String motivo, boolean forcar) {
        Mecanico mec = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Mecânico #" + id + " não encontrado."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        List<Integer> osVinculadas = jdbcTemplate.queryForList(
                "SELECT codigo FROM ordens_servico WHERE mecanicos_codigo = ?", Integer.class, id);

        if (!osVinculadas.isEmpty()) {
            if (!forcar) {
                String listaOs = osVinculadas.stream().map(n -> "#" + n).collect(Collectors.joining(", "));
                throw new IllegalArgumentException(
                        "Não é possível excluir o mecânico '" + mec.getNome()
                                + "' pois ele está vinculado à(s) Ordem(ns) de Serviço " + listaOs +
                                ". Exclua a O.S. primeiro ou marque a opção 'Forçar exclusão removendo vínculos'.");
            }
            for (Integer osId : osVinculadas) {
                osService.excluir(osId, "Exclusão em cascata do Mecânico #" + id + ": " + motivoValidado);
            }
        }

        String descricaoLog = "Mecânico #" + mec.getCodigo() + " - " + mec.getNome() + " (CPF: " + mec.getCpf()
                + ", Comissão: " + mec.getComissao() + "%)";

        int outrosPapeis = obterContagemOutrosPapeis(id);
        jdbcTemplate.update("DELETE FROM mecanicos WHERE pessoas_codigo = ?", id);
        if (outrosPapeis == 0) {
            jdbcTemplate.update("DELETE FROM pessoas WHERE codigo = ?", id);
        }
        entityManager.flush();
        entityManager.clear();

        auditoriaService.registrarExclusao("mecanicos", "EXCLUSAO_MECANICO", descricaoLog, motivoValidado);
    }

    private void validarENormalizar(Mecanico m) {
        if (m.getNome() == null || m.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome completo do mecânico é obrigatório.");
        }
        m.setNome(m.getNome().trim());

        String cpfLimpo = m.getCpf() != null ? m.getCpf().replaceAll("\\D", "") : "";
        if (cpfLimpo.length() != 11) {
            throw new IllegalArgumentException("O CPF deve conter exatamente 11 dígitos numéricos.");
        }
        m.setCpf(cpfLimpo);

        if (m.getComissao() == null || m.getComissao().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Informe um percentual de comissão válido.");
        }

        if (m.getCep() != null) {
            String cepLimpo = m.getCep().replaceAll("\\D", "");
            m.setCep(cepLimpo.isEmpty() ? null : (cepLimpo.length() > 8 ? cepLimpo.substring(0, 8) : cepLimpo));
        }

        if (m.getEmail() != null) {
            String emailTrim = m.getEmail().trim();
            m.setEmail(emailTrim.isEmpty() ? null : emailTrim);
        }

        if (m.getTelefone() != null) {
            String telTrim = m.getTelefone().trim();
            m.setTelefone(telTrim.isEmpty() ? null : telTrim);
        }
    }

    private void verificarConflitoCpfEmail(String cpf, String email, Integer ignorarCodigo) {
        pessoaRepository.findByCpf(cpf).ifPresent(p -> {
            if (ignorarCodigo == null || !p.getCodigo().equals(ignorarCodigo)) {
                throw new IllegalArgumentException(
                        "O CPF " + cpf + " já pertence a outro cadastro (" + p.getNome() + ").");
            }
        });
        if (email != null && !email.isBlank()) {
            pessoaRepository.findByEmail(email).ifPresent(p -> {
                if (ignorarCodigo == null || !p.getCodigo().equals(ignorarCodigo)) {
                    throw new IllegalArgumentException(
                            "O e-mail '" + email + "' já está cadastrado para " + p.getNome() + ".");
                }
            });
        }
    }

    private int obterContagemOutrosPapeis(Integer pessoaCodigo) {
        Integer c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM clientes WHERE pessoas_codigo = ?", Integer.class,
                pessoaCodigo);
        Integer f = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM funcionarios WHERE pessoas_codigo = ?",
                Integer.class, pessoaCodigo);
        return (c != null ? c : 0) + (f != null ? f : 0);
    }
}
