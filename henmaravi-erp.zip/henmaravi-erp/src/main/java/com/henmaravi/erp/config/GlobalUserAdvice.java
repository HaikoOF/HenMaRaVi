package com.henmaravi.erp.config;

import com.henmaravi.erp.entity.Usuario;
import com.henmaravi.erp.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalUserAdvice {

    @Autowired
    private UsuarioService usuarioService;

    @ModelAttribute("usuarioLogado")
    public Usuario getUsuarioLogado() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getPrincipal())) {
            return usuarioService.buscarPorUsername(auth.getName()).orElse(null);
        }
        return null;
    }
}

