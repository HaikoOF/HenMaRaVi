package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Usuario;
import com.henmaravi.erp.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class LoginController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/lembrete-senha")
    public String exibirLembreteSenha() {
        return "lembrete-senha";
    }

    @PostMapping("/lembrete-senha")
    public String consultarLembrete(@RequestParam("termo") String termo, Model model) {
        Optional<Usuario> opt = usuarioService.buscarPorUsernameOuEmail(termo);
        if (opt.isPresent()) {
            Usuario u = opt.get();
            model.addAttribute("usuarioEncontrado", u);
            model.addAttribute("dica", (u.getDicaSenha() != null && !u.getDicaSenha().isBlank())
                    ? u.getDicaSenha()
                    : "Nenhuma dica cadastrada para este usuário.");
        } else {
            model.addAttribute("erro", "Nenhum usuário encontrado para o login ou e-mail informado.");
        }
        return "lembrete-senha";
    }

    @PostMapping("/redefinir-senha")
    public String redefinirSenha(@RequestParam("username") String username,
            @RequestParam("email") String email,
            @RequestParam("novaSenha") String novaSenha,
            RedirectAttributes ra) {
        try {
            usuarioService.redefinirSenha(username, email, novaSenha);
            ra.addFlashAttribute("sucesso", "Senha redefinida com sucesso! Entre com a nova senha.");
            return "redirect:/login";
        } catch (Exception e) {
            ra.addFlashAttribute("erro", e.getMessage());
            return "redirect:/lembrete-senha";
        }
    }

    @GetMapping("/perfil")
    public String exibirPerfil(Authentication auth, Model model) {
        Usuario u = usuarioService.buscarPorUsername(auth.getName())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado."));
        model.addAttribute("usuario", u);
        return "pages/perfil/index";
    }

    @PostMapping("/perfil")
    public String salvarPerfil(Authentication auth,
            @RequestParam("nomeCompleto") String nomeCompleto,
            @RequestParam("email") String email,
            @RequestParam(value = "novaSenha", required = false) String novaSenha,
            @RequestParam(value = "dicaSenha", required = false) String dicaSenha,
            RedirectAttributes ra) {
        try {
            usuarioService.atualizarPerfil(auth.getName(), nomeCompleto, email, novaSenha, dicaSenha);
            ra.addFlashAttribute("sucesso", "Seu perfil foi atualizado com sucesso no banco de dados!");
        } catch (Exception e) {
            ra.addFlashAttribute("erro", "Erro ao atualizar perfil: " + e.getMessage());
        }
        return "redirect:/perfil";
    }

    @GetMapping("/acesso-negado")
    public String acessoNegado() {
        return "pages/acesso-negado";
    }
}
