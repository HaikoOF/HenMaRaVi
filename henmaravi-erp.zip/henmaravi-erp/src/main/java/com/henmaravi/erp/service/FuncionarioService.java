package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Funcionario;
import com.henmaravi.erp.repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FuncionarioService {

    @Autowired
    private FuncionarioRepository repository;

    public List<Funcionario> listarTodos() {
        return repository.findAll();
    }

    public Optional<Funcionario> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public Funcionario salvar(Funcionario entity) {
        return repository.save(entity);
    }

    public void excluir(Integer id) {
        repository.deleteById(id);
    }
}
