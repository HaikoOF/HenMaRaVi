package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Funcionario;
import com.henmaravi.erp.entity.Pessoa;
import com.henmaravi.erp.repository.FuncionarioRepository;
import com.henmaravi.erp.repository.PessoaRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FuncionarioService {

    @Autowired private FuncionarioRepository repository;
    @Autowired private PessoaRepository pessoaRepository;
    @Autowired private JdbcTemplate jdbcTemplate;
    @Autowired private AuditoriaService auditoriaService;
    @Autowired private OrdemServicoService osService;
    @Autowired private CompraService compraService;

    @PersistenceContext
    private EntityManager entityManager;

    public List<Funcionario> listarTodos() {
        return repository.findAll();
    }

    public Optional<Funcionario> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    @Transactional
    public Funcionario salvar(Funcionario dados) {
        validarENormalizar(dados);

        // Caso 1: Edição de Funcionário existente
        if (dados.getCodigo() != null) {
            Funcionario existente = repository.findById(dados.getCodigo())
                    .orElseThrow(() -> new IllegalArgumentException("Funcionário #" + dados.getCodigo() + " não encontrado."));

            verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), existente.getCodigo());

            existente.setNome(dados.getNome());
            existente.setCpf(dados.getCpf());
            if (dados.getTelefone() != null) existente.setTelefone(dados.getTelefone());
            if (dados.getCep() != null) existente.setCep(dados.getCep());
            if (dados.getEmail() != null) existente.setEmail(dados.getEmail());
            existente.setSalario(dados.getSalario());
            return repository.save(existente);
        }

        // Caso 2: Novo Funcionário — Reusar Pessoa caso CPF já exista (Item 8)
        Optional<Pessoa> pessoaExistenteOpt = pessoaRepository.findByCpf(dados.getCpf());
        if (pessoaExistenteOpt.isPresent()) {
            Pessoa p = pessoaExistenteOpt.get();
            if (repository.existsById(p.getCodigo())) {
                throw new IllegalArgumentException("Já existe um Funcionário cadastrado com o CPF " + dados.getCpf() + " (" + p.getNome() + ").");
            }
            verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), p.getCodigo());

            jdbcTemplate.update(
                    "UPDATE pessoas SET nome = ?, telefone = COALESCE(?, telefone), cep = COALESCE(?, cep), email = COALESCE(?, email) WHERE codigo = ?",
                    dados.getNome(), dados.getTelefone(), dados.getCep(), dados.getEmail(), p.getCodigo()
            );
            jdbcTemplate.update(
                    "INSERT INTO funcionarios (pessoas_codigo, salario) VALUES (?, ?)",
                    p.getCodigo(), dados.getSalario()
            );
            entityManager.flush();
            entityManager.clear();
            return repository.findById(p.getCodigo()).orElseThrow();
        }

        verificarConflitoCpfEmail(dados.getCpf(), dados.getEmail(), null);
        return repository.save(dados);
    }

    @Transactional
    public void excluir(Integer id, String motivo, boolean forcar) {
        Funcionario func = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Funcionário #" + id + " não encontrado."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        List<Integer> osVinculadas = jdbcTemplate.queryForList(
                "SELECT codigo FROM ordens_servico WHERE funcionarios_codigo = ?", Integer.class, id
        );
        List<Integer> comprasVinculadas = jdbcTemplate.queryForList(
                "SELECT codigo FROM compras WHERE funcionarios_codigo = ?", Integer.class, id
        );

        if (!osVinculadas.isEmpty() || !comprasVinculadas.isEmpty()) {
            if (!forcar) {
                String msgOs = osVinculadas.isEmpty() ? "" : "Ordens de Serviço (" + osVinculadas.stream().map(n -> "#" + n).collect(Collectors.joining(", ")) + ")";
                String msgComp = comprasVinculadas.isEmpty() ? "" : "Notas de Compra (" + comprasVinculadas.stream().map(n -> "#" + n).collect(Collectors.joining(", ")) + ")";
                String sep = (!msgOs.isEmpty() && !msgComp.isEmpty()) ? " e " : "";
                throw new IllegalArgumentException(
                        "Não é possível excluir o funcionário '" + func.getNome() + "' pois ele possui vínculo em " + msgOs + sep + msgComp +
                        ". Exclua os lançamentos primeiro ou marque a opção 'Forçar exclusão removendo vínculos'."
                );
            }
            for (Integer osId : osVinculadas) {
                osService.excluir(osId, "Exclusão em cascata do Funcionário #" + id + ": " + motivoValidado);
            }
            for (Integer compId : comprasVinculadas) {
                compraService.excluir(compId, "Exclusão em cascata do Funcionário #" + id + ": " + motivoValidado);
            }
        }

        String descricaoLog = "Funcionário #" + func.getCodigo() + " - " + func.getNome() + " (CPF: " + func.getCpf() + ", Salário: R$ " + func.getSalario() + ")";

        int outrosPapeis = obterContagemOutrosPapeis(id);
        jdbcTemplate.update("DELETE FROM funcionarios WHERE pessoas_codigo = ?", id);
        if (outrosPapeis == 0) {
            jdbcTemplate.update("DELETE FROM pessoas WHERE codigo = ?", id);
        }
        entityManager.flush();
        entityManager.clear();

        auditoriaService.registrarExclusao("funcionarios", "EXCLUSAO_FUNCIONARIO", descricaoLog, motivoValidado);
    }

    private void validarENormalizar(Funcionario f) {
        if (f.getNome() == null || f.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome completo do funcionário é obrigatório.");
        }
        f.setNome(f.getNome().trim());

        String cpfLimpo = f.getCpf() != null ? f.getCpf().replaceAll("\\D", "") : "";
        if (cpfLimpo.length() != 11) {
            throw new IllegalArgumentException("O CPF deve conter exatamente 11 dígitos numéricos.");
        }
        f.setCpf(cpfLimpo);

        if (f.getSalario() == null || f.getSalario().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Informe um salário válido para o funcionário.");
        }

        if (f.getCep() != null) {
            String cepLimpo = f.getCep().replaceAll("\\D", "");
            f.setCep(cepLimpo.isEmpty() ? null : (cepLimpo.length() > 8 ? cepLimpo.substring(0, 8) : cepLimpo));
        }

        if (f.getEmail() != null) {
            String emailTrim = f.getEmail().trim();
            f.setEmail(emailTrim.isEmpty() ? null : emailTrim);
        }

        if (f.getTelefone() != null) {
            String telTrim = f.getTelefone().trim();
            f.setTelefone(telTrim.isEmpty() ? null : telTrim);
        }
    }

    private void verificarConflitoCpfEmail(String cpf, String email, Integer ignorarCodigo) {
        pessoaRepository.findByCpf(cpf).ifPresent(p -> {
            if (ignorarCodigo == null || !p.getCodigo().equals(ignorarCodigo)) {
                throw new IllegalArgumentException("O CPF " + cpf + " já pertence a outro cadastro (" + p.getNome() + ").");
            }
        });
        if (email != null && !email.isBlank()) {
            pessoaRepository.findByEmail(email).ifPresent(p -> {
                if (ignorarCodigo == null || !p.getCodigo().equals(ignorarCodigo)) {
                    throw new IllegalArgumentException("O e-mail '" + email + "' já está cadastrado para " + p.getNome() + ".");
                }
            });
        }
    }

    private int obterContagemOutrosPapeis(Integer pessoaCodigo) {
        Integer c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM clientes WHERE pessoas_codigo = ?", Integer.class, pessoaCodigo);
        Integer m = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM mecanicos WHERE pessoas_codigo = ?", Integer.class, pessoaCodigo);
        return (c != null ? c : 0) + (m != null ? m : 0);
    }
}
