package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Usuario;
import com.henmaravi.erp.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/usuarios")
    public String index(Model model) {
        model.addAttribute("usuarios", usuarioService.listarTodos());
        return "pages/usuarios/index";
    }

    @GetMapping("/api/usuarios")
    @ResponseBody
    public List<Usuario> listarAPI() {
        return usuarioService.listarTodos();
    }

    @GetMapping("/api/usuarios/{id}")
    @ResponseBody
    public ResponseEntity<Usuario> buscarPorId(@PathVariable Integer id) {
        return usuarioService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/usuarios")
    @ResponseBody
    public Usuario criar(@RequestBody Usuario usuario) {
        return usuarioService.salvarContaPeloAdmin(usuario);
    }

    @PutMapping("/api/usuarios/{id}")
    @ResponseBody
    public ResponseEntity<Usuario> atualizar(@PathVariable Integer id, @RequestBody Usuario usuario) {
        if (usuarioService.buscarPorId(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        usuario.setCodigo(id);
        return ResponseEntity.ok(usuarioService.salvarContaPeloAdmin(usuario));
    }

    @DeleteMapping("/api/usuarios/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(
            @PathVariable Integer id,
            @RequestParam(value = "motivo", required = false) String motivo) {
        usuarioService.excluir(id, motivo);
        return ResponseEntity.noContent().build();
    }
}

