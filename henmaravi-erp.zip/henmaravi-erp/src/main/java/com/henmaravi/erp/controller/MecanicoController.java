package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Mecanico;
import com.henmaravi.erp.service.MecanicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class MecanicoController {

    @Autowired
    private MecanicoService service;

    @GetMapping("/mecanicos")
    public String index(Model model) {
        model.addAttribute("mecanicos", service.listarTodos());
        return "pages/mecanicos/index";
    }

    @GetMapping("/api/mecanicos")
    @ResponseBody
    public List<Mecanico> listarAPI() {
        return service.listarTodos();
    }

    @GetMapping("/api/mecanicos/{id}")
    @ResponseBody
    public ResponseEntity<Mecanico> buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/mecanicos")
    @ResponseBody
    public Mecanico salvar(@RequestBody Mecanico entity) {
        return service.salvar(entity);
    }

    @PutMapping("/api/mecanicos/{id}")
    @ResponseBody
    public ResponseEntity<Mecanico> atualizar(@PathVariable Integer id, @RequestBody Mecanico entity) {
        if (!service.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        entity.setCodigo(id);
        return ResponseEntity.ok(service.salvar(entity));
    }

    @DeleteMapping("/api/mecanicos/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(@PathVariable Integer id) {
        if (!service.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
