package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Veiculo;
import com.henmaravi.erp.service.VeiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class VeiculoController {

    @Autowired
    private VeiculoService veiculoService;

    @GetMapping("/veiculos")
    public String index(Model model) {
        model.addAttribute("veiculos", veiculoService.listarTodos());
        return "pages/veiculos/index";
    }

    @GetMapping("/api/veiculos")
    @ResponseBody
    public List<Veiculo> listarAPI() {
        return veiculoService.listarTodos();
    }

    @GetMapping("/api/veiculos/{id}")
    @ResponseBody
    public ResponseEntity<Veiculo> buscarPorId(@PathVariable Integer id) {
        return veiculoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/veiculos")
    @ResponseBody
    public Veiculo salvar(@RequestBody Veiculo veiculo) {
        return veiculoService.salvar(veiculo);
    }

    @PutMapping("/api/veiculos/{id}")
    @ResponseBody
    public ResponseEntity<Veiculo> atualizar(@PathVariable Integer id, @RequestBody Veiculo veiculo) {
        if (veiculoService.buscarPorId(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        veiculo.setCodigo(id);
        return ResponseEntity.ok(veiculoService.salvar(veiculo));
    }

    @DeleteMapping("/api/veiculos/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(
            @PathVariable Integer id,
            @RequestParam(value = "motivo", required = false) String motivo,
            @RequestParam(value = "forcar", required = false, defaultValue = "false") boolean forcar) {
        veiculoService.excluir(id, motivo, forcar);
        return ResponseEntity.noContent().build();
    }
}
