package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Funcionario;
import com.henmaravi.erp.service.FuncionarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class FuncionarioController {

    @Autowired
    private FuncionarioService service;

    @GetMapping("/funcionarios")
    public String index(Model model) {
        model.addAttribute("funcionarios", service.listarTodos());
        return "pages/funcionarios/index";
    }

    @GetMapping("/api/funcionarios")
    @ResponseBody
    public List<Funcionario> listarAPI() {
        return service.listarTodos();
    }

    @GetMapping("/api/funcionarios/{id}")
    @ResponseBody
    public ResponseEntity<Funcionario> buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/api/funcionarios")
    @ResponseBody
    public Funcionario salvar(@RequestBody Funcionario entity) {
        return service.salvar(entity);
    }

    @PutMapping("/api/funcionarios/{id}")
    @ResponseBody
    public ResponseEntity<Funcionario> atualizar(@PathVariable Integer id, @RequestBody Funcionario entity) {
        if (!service.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        entity.setCodigo(id);
        return ResponseEntity.ok(service.salvar(entity));
    }

    @DeleteMapping("/api/funcionarios/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(@PathVariable Integer id) {
        if (!service.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
