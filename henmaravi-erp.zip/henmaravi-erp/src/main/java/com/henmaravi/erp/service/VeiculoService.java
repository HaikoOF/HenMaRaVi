package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Veiculo;
import com.henmaravi.erp.repository.VeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class VeiculoService {

    @Autowired
    private VeiculoRepository veiculoRepository;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private AuditoriaService auditoriaService;
    @Autowired
    private OrdemServicoService osService;

    public List<Veiculo> listarTodos() {
        return veiculoRepository.findAll();
    }

    public Optional<Veiculo> buscarPorId(Integer id) {
        return veiculoRepository.findById(id);
    }

    @Transactional
    public Veiculo salvar(Veiculo veiculo) {
        if (veiculo.getPlaca() == null || veiculo.getPlaca().trim().isEmpty()) {
            throw new IllegalArgumentException("A placa do veículo é obrigatória.");
        }
        String placaLimpa = veiculo.getPlaca().replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        if (placaLimpa.length() != 7) {
            throw new IllegalArgumentException("A placa deve conter 7 caracteres (ex: ABC1234 ou ABC1D23).");
        }
        veiculo.setPlaca(placaLimpa);

        if (veiculo.getDescricao() == null || veiculo.getDescricao().trim().isEmpty()) {
            throw new IllegalArgumentException("A descrição/modelo do veículo é obrigatória.");
        }
        veiculo.setDescricao(veiculo.getDescricao().trim());

        if (veiculo.getPreco() == null || veiculo.getPreco().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Informe um preço padrão válido para o veículo.");
        }

        // Verifica duplicidade de placa
        List<Integer> existentes = jdbcTemplate.queryForList(
                "SELECT codigo FROM veiculos WHERE placa = ?", Integer.class, placaLimpa);
        for (Integer cod : existentes) {
            if (veiculo.getCodigo() == null || !cod.equals(veiculo.getCodigo())) {
                throw new IllegalArgumentException("Já existe um veículo cadastrado com a placa '" + placaLimpa + "'.");
            }
        }

        return veiculoRepository.save(veiculo);
    }

    @Transactional
    public void excluir(Integer id, String motivo, boolean forcar) {
        Veiculo v = veiculoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Veículo #" + id + " não encontrado."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        List<Integer> osVinculadas = jdbcTemplate.queryForList(
                "SELECT codigo FROM ordens_servico WHERE veiculos_codigo = ?", Integer.class, id);

        if (!osVinculadas.isEmpty()) {
            if (!forcar) {
                String listaOs = osVinculadas.stream().map(n -> "#" + n).collect(Collectors.joining(", "));
                throw new IllegalArgumentException(
                        "Não é possível excluir o veículo '" + v.getDescricao() + " (Placa: " + v.getPlaca()
                                + ")' pois ele está vinculado à(s) Ordem(ns) de Serviço " + listaOs +
                                ". Exclua a O.S. primeiro ou marque a opção 'Forçar exclusão removendo vínculos'.");
            }
            for (Integer osId : osVinculadas) {
                osService.excluir(osId, "Exclusão em cascata do Veículo placa " + v.getPlaca() + ": " + motivoValidado);
            }
        }

        String descricaoLog = "Veículo #" + v.getCodigo() + " - Placa: " + v.getPlaca() + " (" + v.getDescricao() + ")";
        veiculoRepository.deleteById(id);

        auditoriaService.registrarExclusao("veiculos", "EXCLUSAO_VEICULO", descricaoLog, motivoValidado);
    }
}
