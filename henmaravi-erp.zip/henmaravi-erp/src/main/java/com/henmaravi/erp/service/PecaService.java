package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Peca;
import com.henmaravi.erp.repository.PecaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PecaService {

    @Autowired
    private PecaRepository pecaRepository;

    public List<Peca> listarTodos() {
        return pecaRepository.findAll();
    }

    public Optional<Peca> buscarPorId(Integer id) {
        return pecaRepository.findById(id);
    }

    public Peca salvar(Peca peca) {
        return pecaRepository.save(peca);
    }

    public void excluir(Integer id) {
        pecaRepository.deleteById(id);
    }
}
