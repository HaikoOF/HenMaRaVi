package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Peca;
import com.henmaravi.erp.repository.PecaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class PecaService {

    @Autowired
    private PecaRepository pecaRepository;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private AuditoriaService auditoriaService;

    public List<Peca> listarTodos() {
        return pecaRepository.findAll();
    }

    public Optional<Peca> buscarPorId(Integer id) {
        return pecaRepository.findById(id);
    }

    @Transactional
    public Peca salvar(Peca peca) {
        if (peca.getNumero() == null || peca.getNumero().trim().isEmpty()) {
            throw new IllegalArgumentException("O código/SKU da peça é obrigatório.");
        }
        peca.setNumero(peca.getNumero().trim().toUpperCase());

        if (peca.getNome() == null || peca.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome da peça é obrigatório.");
        }
        peca.setNome(peca.getNome().trim());

        if (peca.getPreco() == null || peca.getPreco().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Informe um preço unitário válido para a peça.");
        }
        if (peca.getEstoque() == null || peca.getEstoque() < 0) {
            throw new IllegalArgumentException("A quantidade em estoque não pode ser negativa.");
        }

        List<Integer> existentes = jdbcTemplate.queryForList(
                "SELECT codigo FROM pecas WHERE numero = ?", Integer.class, peca.getNumero());
        for (Integer cod : existentes) {
            if (peca.getCodigo() == null || !cod.equals(peca.getCodigo())) {
                throw new IllegalArgumentException(
                        "Já existe uma peça cadastrada com o Código/SKU '" + peca.getNumero() + "'.");
            }
        }

        return pecaRepository.save(peca);
    }

    @Transactional
    public void excluir(Integer id, String motivo, boolean forcar) {
        Peca peca = pecaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Peça #" + id + " não encontrada."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        Integer qtdOs = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ordens_servico_pecas WHERE pecas_codigo = ?", Integer.class, id);
        Integer qtdCompras = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM pecas_compras WHERE pecas_codigo = ?", Integer.class, id);

        if ((qtdOs != null && qtdOs > 0) || (qtdCompras != null && qtdCompras > 0)) {
            if (!forcar) {
                throw new IllegalArgumentException(
                        "Não é possível excluir a peça '" + peca.getNumero() + " - " + peca.getNome() +
                                "' pois ela já foi utilizada em Ordens de Serviço ou Notas de Compra. Marque 'Forçar exclusão removendo vínculos' se desejar removê-la.");
            }
            jdbcTemplate.update("DELETE FROM ordens_servico_pecas WHERE pecas_codigo = ?", id);
            jdbcTemplate.update("DELETE FROM pecas_compras WHERE pecas_codigo = ?", id);
        }

        String descricaoLog = "Peça #" + peca.getCodigo() + " (" + peca.getNumero() + " - " + peca.getNome()
                + ", Estoque: " + peca.getEstoque() + ")";
        pecaRepository.deleteById(id);

        auditoriaService.registrarExclusao("pecas", "EXCLUSAO_PECA", descricaoLog, motivoValidado);
    }
}
