package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.LogAuditoria;
import com.henmaravi.erp.entity.Usuario;
import com.henmaravi.erp.repository.LogAuditoriaRepository;
import com.henmaravi.erp.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class AuditoriaService {

    @Autowired
    private LogAuditoriaRepository logRepo;

    @Autowired
    private UsuarioRepository usuarioRepo;

    public String obterUsuarioLogadoFormatado() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getPrincipal())) {
            String username = auth.getName();
            Optional<Usuario> opt = usuarioRepo.findByUsername(username);
            if (opt.isPresent()) {
                Usuario u = opt.get();
                return u.getUsername() + " (" + u.getNomeCompleto() + " - " + u.getPerfil() + ")";
            }
            return username;
        }
        return "Sistema";
    }

    public String validarMotivoObrigatorio(String motivo) {
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new IllegalArgumentException("É obrigatório informar o motivo da exclusão para registro na auditoria.");
        }
        return motivo.trim();
    }

    public void registrarExclusao(String tabelaAfetada, String acao, String descricao, String motivo) {
        String motivoValidado = validarMotivoObrigatorio(motivo);
        String responsavel = obterUsuarioLogadoFormatado();

        LogAuditoria log = new LogAuditoria();
        log.setDataEvento(new Date());
        log.setUsuarioResponsavel(responsavel);
        log.setMotivo(motivoValidado);
        log.setTabelaAfetada(tabelaAfetada);
        log.setAcao(acao != null ? acao : "EXCLUSAO");
        log.setDescricao(descricao + " | Excluído por: " + responsavel + " | Motivo: " + motivoValidado);
        logRepo.save(log);
    }

    public List<LogAuditoria> listarTodosLogs() {
        return logRepo.findTop100ByOrderByDataEventoDesc();
    }

    public List<LogAuditoria> listarLogsExclusao() {
        return logRepo.findByAcaoStartingWithOrderByDataEventoDesc("EXCLUSAO");
    }

    public List<LogAuditoria> listarLogsComprasEstoque() {
        return logRepo.findByTabelaAfetadaInOrderByDataEventoDesc(List.of("compras", "pecas_compras", "pecas"));
    }
}

