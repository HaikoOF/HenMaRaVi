package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Table(name = "logs_auditoria")
@Data
public class LogAuditoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;

    @Column(name = "data_evento", columnDefinition = "DATETIME DEFAULT GETDATE()")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEvento;

    @Column(name = "usuario_responsavel", length = 100)
    private String usuarioResponsavel;

    @Column(name = "motivo", length = 500)
    private String motivo;

    @Column(name = "tabela_afetada", nullable = false, length = 100)
    private String tabelaAfetada;

    @Column(nullable = false, length = 50)
    private String acao;

    @Column(nullable = false, length = 500)
    private String descricao;
}
