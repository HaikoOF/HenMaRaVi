package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Servico;
import com.henmaravi.erp.repository.ServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class ServicoService {

    @Autowired
    private ServicoRepository servicoRepository;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private AuditoriaService auditoriaService;

    public List<Servico> listarTodos() {
        return servicoRepository.findAll();
    }

    public Optional<Servico> buscarPorId(Integer id) {
        return servicoRepository.findById(id);
    }

    @Transactional
    public Servico salvar(Servico servico) {
        if (servico.getDescricao() == null || servico.getDescricao().trim().isEmpty()) {
            throw new IllegalArgumentException("A descrição do serviço é obrigatória.");
        }
        servico.setDescricao(servico.getDescricao().trim());

        if (servico.getPreco() == null || servico.getPreco().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Informe um valor padrão válido para o serviço.");
        }

        return servicoRepository.save(servico);
    }

    @Transactional
    public void excluir(Integer id, String motivo, boolean forcar) {
        Servico s = servicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Serviço #" + id + " não encontrado."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        Integer qtdOs = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ordens_servico_servicos WHERE servicos_codigo = ?", Integer.class, id);

        if (qtdOs != null && qtdOs > 0) {
            if (!forcar) {
                throw new IllegalArgumentException(
                        "Não é possível excluir o serviço '" + s.getDescricao() +
                                "' pois ele está vinculado a Ordens de Serviço existentes. Marque 'Forçar exclusão removendo vínculos' se desejar removê-lo.");
            }
            jdbcTemplate.update("DELETE FROM ordens_servico_servicos WHERE servicos_codigo = ?", id);
        }

        String descricaoLog = "Serviço #" + s.getCodigo() + " - " + s.getDescricao() + " (R$ " + s.getPreco() + ")";
        servicoRepository.deleteById(id);

        auditoriaService.registrarExclusao("servicos", "EXCLUSAO_SERVICO", descricaoLog, motivoValidado);
    }
}
