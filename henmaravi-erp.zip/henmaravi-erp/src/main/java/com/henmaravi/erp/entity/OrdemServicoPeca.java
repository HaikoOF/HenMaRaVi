package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "ordens_servico_pecas")
@Data
public class OrdemServicoPeca {

    @EmbeddedId
    private OrdemServicoPecaId id = new OrdemServicoPecaId();

    @ManyToOne(optional = false)
    @MapsId("ordemServicoCodigo")
    @JoinColumn(name = "ordens_servico_codigo", nullable = false)
    private OrdemServico ordemServico;

    @ManyToOne(optional = false)
    @MapsId("pecaCodigo")
    @JoinColumn(name = "pecas_codigo", nullable = false)
    private Peca peca;

    @Column(nullable = false)
    private Integer qtd;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal preco;

    // Getter auxiliar para serialização JSON no front-end (evita undefined em p.pecaCodigo)
    public Integer getPecaCodigo() {
        if (peca != null && peca.getCodigo() != null) {
            return peca.getCodigo();
        }
        return id != null ? id.getPecaCodigo() : null;
    }
}
