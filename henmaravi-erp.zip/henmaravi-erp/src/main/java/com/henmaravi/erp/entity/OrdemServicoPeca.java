package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "ordens_servico_pecas")
@Data
public class OrdemServicoPeca {

    @EmbeddedId
    private OrdemServicoPecaId id = new OrdemServicoPecaId();

    @ManyToOne(optional = false)
    @MapsId("ordemServicoCodigo")
    @JoinColumn(name = "ordens_servico_codigo", nullable = false)
    private OrdemServico ordemServico;

    @ManyToOne(optional = false)
    @MapsId("pecaCodigo")
    @JoinColumn(name = "pecas_codigo", nullable = false)
    private Peca peca;

    @Column(nullable = false)
    private Integer qtd;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal preco;
}
