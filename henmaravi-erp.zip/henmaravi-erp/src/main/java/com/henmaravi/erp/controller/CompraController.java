package com.henmaravi.erp.controller;

import com.henmaravi.erp.entity.Compra;
import com.henmaravi.erp.entity.PecaCompra;
import com.henmaravi.erp.service.CompraService;
import com.henmaravi.erp.service.FuncionarioService;
import com.henmaravi.erp.service.PecaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
public class CompraController {

    @Autowired
    private CompraService compraService;
    @Autowired
    private FuncionarioService funcionarioService;
    @Autowired
    private PecaService pecaService;

    @GetMapping("/compras")
    public String index(Model model) {
        model.addAttribute("compras", compraService.listarTodas());
        return "pages/compras/index";
    }

    @GetMapping("/compras/nova")
    public String nova(Model model) {
        model.addAttribute("funcionarios", funcionarioService.listarTodos());
        return "pages/compras/form";
    }

    @GetMapping("/compras/{id}/editar")
    public String editar(@PathVariable Integer id, Model model) {
        model.addAttribute("compra", compraService.buscarPorId(id).orElseThrow());
        model.addAttribute("funcionarios", funcionarioService.listarTodos());
        model.addAttribute("pecasCatalogo", pecaService.listarTodos());
        return "pages/compras/form";
    }

    @PostMapping("/api/compras")
    @ResponseBody
    public Compra salvar(@RequestBody Compra compra) {
        return compraService.salvar(compra);
    }

    @DeleteMapping("/api/compras/{id}")
    @ResponseBody
    public ResponseEntity<Void> excluir(
            @PathVariable Integer id,
            @RequestParam(value = "motivo", required = false) String motivo) {
        compraService.excluir(id, motivo);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/compras/{id}/totais")
    @ResponseBody
    public Map<String, Object> totais(@PathVariable Integer id) {
        Compra c = compraService.buscarPorId(id).orElseThrow();
        return Map.of("total", c.getValorTotal());
    }

    @GetMapping("/api/compras/{id}/pecas")
    @ResponseBody
    public List<PecaCompra> listarPecas(@PathVariable Integer id) {
        return compraService.listarPecas(id);
    }

    @PostMapping("/api/compras/{id}/pecas")
    @ResponseBody
    public ResponseEntity<?> addPeca(@PathVariable Integer id, @RequestBody Map<String, Object> payload) {
        Integer pecaId = Integer.parseInt(payload.get("pecaId").toString());
        Integer qtd = Integer.parseInt(payload.get("qtd").toString());
        BigDecimal preco = new BigDecimal(payload.get("preco").toString());
        return ResponseEntity.ok(compraService.adicionarPeca(id, pecaId, qtd, preco));
    }

    @DeleteMapping("/api/compras/{id}/pecas/{pecaId}")
    @ResponseBody
    public ResponseEntity<Void> removePeca(
            @PathVariable Integer id,
            @PathVariable Integer pecaId,
            @RequestParam(value = "motivo", required = false) String motivo) {
        compraService.removerPeca(id, pecaId, motivo);
        return ResponseEntity.noContent().build();
    }
}
