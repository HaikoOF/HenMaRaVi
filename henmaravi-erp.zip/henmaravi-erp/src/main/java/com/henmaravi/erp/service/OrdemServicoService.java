package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.*;
import com.henmaravi.erp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class OrdemServicoService {

    @Autowired private OrdemServicoRepository osRepo;
    @Autowired private OrdemServicoPecaRepository osPecaRepo;
    @Autowired private OrdemServicoServicoRepository osServicoRepo;
    @Autowired private PecaRepository pecaRepo;
    @Autowired private ServicoRepository servicoRepo;

    public List<OrdemServico> listarTodas() {
        return osRepo.findAll();
    }

    public Optional<OrdemServico> buscarPorId(Integer id) {
        return osRepo.findById(id);
    }

    @Transactional
    public OrdemServico salvar(OrdemServico os) {
        // Se for uma O.S. nova, já crava a data de hoje pra não ter erro
        if(os.getDataAbertura() == null) os.setDataAbertura(new Date());
        
        // Toda O.S. começa aberta por padrão, a não ser que o cara mude na hora
        if(os.getStatus() == null || os.getStatus().isEmpty()) os.setStatus("Aberta");
        
        return osRepo.save(os);
    }

    public void excluir(Integer id) {
        // Atenção aqui: não dá pra excluir a O.S. direto se ela tiver itens atrelados
        // Então primeiro a gente limpa as peças e os serviços, depois mata a O.S.
        osPecaRepo.deleteAll(listarPecas(id));
        osServicoRepo.deleteAll(listarServicos(id));
        osRepo.deleteById(id);
    }

    // -- Itens --
    public List<OrdemServicoPeca> listarPecas(Integer osId) {
        return osPecaRepo.findByIdOrdemServicoCodigo(osId);
    }

    public List<OrdemServicoServico> listarServicos(Integer osId) {
        return osServicoRepo.findByIdOrdemServicoCodigo(osId);
    }

    @Transactional
    public OrdemServicoPeca adicionarPeca(Integer osId, Integer pecaId, Integer qtd) {
        OrdemServico os = osRepo.findById(osId).orElseThrow(() -> new RuntimeException("Eita, não achamos essa O.S."));
        Peca peca = pecaRepo.findById(pecaId).orElseThrow(() -> new RuntimeException("Peça não encontrada no catálogo"));

        // Barra a inserção se o cara tentar colocar mais peças do que a gente tem na prateleira
        if (peca.getEstoque() < qtd) {
            throw new RuntimeException("Estoque insuficiente. Só temos " + peca.getEstoque() + " dessa peça.");
        }

        // Já tira do estoque na hora pra não correr o risco de vender a mesma peça pra duas O.S. diferentes
        peca.setEstoque(peca.getEstoque() - qtd);
        pecaRepo.save(peca);

        OrdemServicoPeca item = new OrdemServicoPeca();
        item.getId().setOrdemServicoCodigo(osId);
        item.getId().setPecaCodigo(pecaId);
        item.setOrdemServico(os);
        item.setPeca(peca);
        item.setQtd(qtd);
        item.setPreco(peca.getPreco());

        return osPecaRepo.save(item);
    }

    @Transactional
    public void removerPeca(Integer osId, Integer pecaId) {
        OrdemServicoPecaId id = new OrdemServicoPecaId();
        id.setOrdemServicoCodigo(osId);
        id.setPecaCodigo(pecaId);

        osPecaRepo.findById(id).ifPresent(item -> {
            // Como o cliente tirou a peça da O.S., a gente devolve pro estoque físico
            Peca peca = item.getPeca();
            peca.setEstoque(peca.getEstoque() + item.getQtd()); 
            pecaRepo.save(peca);
            
            // Depois de devolver, apaga o registro da relação
            osPecaRepo.delete(item);
        });
    }

    @Transactional
    public OrdemServicoServico adicionarServico(Integer osId, Integer servicoId, Integer qtd) {
        OrdemServico os = osRepo.findById(osId).orElseThrow(() -> new RuntimeException("OS não encontrada"));
        Servico servico = servicoRepo.findById(servicoId).orElseThrow(() -> new RuntimeException("Serviço não encontrado"));

        OrdemServicoServico item = new OrdemServicoServico();
        item.getId().setOrdemServicoCodigo(osId);
        item.getId().setServicoCodigo(servicoId);
        item.setOrdemServico(os);
        item.setServico(servico);
        item.setQtd(qtd);
        item.setPreco(servico.getPreco());

        return osServicoRepo.save(item);
    }

    @Transactional
    public void removerServico(Integer osId, Integer servicoId) {
        OrdemServicoServicoId id = new OrdemServicoServicoId();
        id.setOrdemServicoCodigo(osId);
        id.setServicoCodigo(servicoId);
        osServicoRepo.deleteById(id);
    }

    public BigDecimal calcularTotal(Integer osId) {
        // Soma o custo de todas as peças multiplicando pela quantidade
        BigDecimal totalPecas = listarPecas(osId).stream()
                .map(p -> p.getPreco().multiply(new BigDecimal(p.getQtd())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Mesma coisa pros serviços, pega o valor hora/serviço * qtd e soma tudo
        BigDecimal totalServicos = listarServicos(osId).stream()
                .map(s -> s.getPreco().multiply(new BigDecimal(s.getQtd())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // O valor final que o cliente vai pagar é a soma de tudo
        return totalPecas.add(totalServicos);
    }
}
