package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.*;
import com.henmaravi.erp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class OrdemServicoService {

    @Autowired
    private OrdemServicoRepository osRepo;
    @Autowired
    private OrdemServicoPecaRepository osPecaRepo;
    @Autowired
    private OrdemServicoServicoRepository osServicoRepo;
    @Autowired
    private PecaRepository pecaRepo;
    @Autowired
    private ServicoRepository servicoRepo;
    @Autowired
    private AuditoriaService auditoriaService;

    public List<OrdemServico> listarTodas() {
        return osRepo.findAll();
    }

    public Optional<OrdemServico> buscarPorId(Integer id) {
        return osRepo.findById(id);
    }

    @Transactional
    public OrdemServico salvar(OrdemServico os) {
        if (os.getCliente() == null || os.getCliente().getCodigo() == null) {
            throw new IllegalArgumentException("Selecione o cliente da Ordem de Serviço.");
        }
        if (os.getVeiculo() == null || os.getVeiculo().getCodigo() == null) {
            throw new IllegalArgumentException("Selecione o veículo da Ordem de Serviço.");
        }
        if (os.getMecanico() == null || os.getMecanico().getCodigo() == null) {
            throw new IllegalArgumentException("Selecione o mecânico responsável.");
        }
        if (os.getFuncionario() == null || os.getFuncionario().getCodigo() == null) {
            throw new IllegalArgumentException("Selecione o atendente responsável.");
        }

        if (os.getCodigo() != null) {
            Optional<OrdemServico> existenteOpt = osRepo.findById(os.getCodigo());
            if (existenteOpt.isPresent()) {
                OrdemServico existente = existenteOpt.get();
                existente.setStatus(
                        os.getStatus() != null && !os.getStatus().isEmpty() ? os.getStatus() : existente.getStatus());
                existente.setCliente(os.getCliente());
                existente.setVeiculo(os.getVeiculo());
                existente.setMecanico(os.getMecanico());
                existente.setFuncionario(os.getFuncionario());
                return osRepo.save(existente);
            }
        }

        if (os.getDataAbertura() == null)
            os.setDataAbertura(new Date());
        if (os.getStatus() == null || os.getStatus().isEmpty())
            os.setStatus("Aberta");

        return osRepo.save(os);
    }

    @Transactional
    public void excluir(Integer id, String motivo) {
        OrdemServico os = osRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Ordem de Serviço #" + id + " não encontrada."));

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        List<OrdemServicoPeca> pecasOs = listarPecas(id);
        for (OrdemServicoPeca item : pecasOs) {
            Peca peca = item.getPeca();
            peca.setEstoque(peca.getEstoque() + item.getQtd());
            pecaRepo.save(peca);
        }

        osPecaRepo.deleteAll(pecasOs);
        osServicoRepo.deleteAll(listarServicos(id));
        osRepo.deleteById(id);

        String descricaoLog = "Ordem de Serviço #" + id + " (Cliente: " +
                (os.getCliente() != null ? os.getCliente().getNome() : "-") +
                ", Veículo: " + (os.getVeiculo() != null ? os.getVeiculo().getPlaca() : "-") +
                ", Status: " + os.getStatus() + ")";

        auditoriaService.registrarExclusao("ordens_servico", "EXCLUSAO_OS", descricaoLog, motivoValidado);
    }

    // -- Itens --
    public List<OrdemServicoPeca> listarPecas(Integer osId) {
        return osPecaRepo.findByIdOrdemServicoCodigo(osId);
    }

    public List<OrdemServicoServico> listarServicos(Integer osId) {
        return osServicoRepo.findByIdOrdemServicoCodigo(osId);
    }

    @Transactional
    public OrdemServicoPeca adicionarPeca(Integer osId, Integer pecaId, Integer qtd) {
        if (qtd == null || qtd <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }
        OrdemServico os = osRepo.findById(osId)
                .orElseThrow(() -> new IllegalArgumentException("Ordem de Serviço #" + osId + " não encontrada."));
        Peca peca = pecaRepo.findById(pecaId)
                .orElseThrow(() -> new IllegalArgumentException("Peça #" + pecaId + " não encontrada no catálogo."));

        if (peca.getEstoque() < qtd) {
            throw new IllegalArgumentException(
                    "Estoque insuficiente para '" + peca.getNome() + "'. Disponível: " + peca.getEstoque() + " un.");
        }

        peca.setEstoque(peca.getEstoque() - qtd);
        pecaRepo.save(peca);

        OrdemServicoPecaId id = new OrdemServicoPecaId();
        id.setOrdemServicoCodigo(osId);
        id.setPecaCodigo(pecaId);

        Optional<OrdemServicoPeca> existenteOpt = osPecaRepo.findById(id);
        OrdemServicoPeca item;
        if (existenteOpt.isPresent()) {
            item = existenteOpt.get();
            item.setQtd(item.getQtd() + qtd);
            item.setPreco(peca.getPreco());
        } else {
            item = new OrdemServicoPeca();
            item.setId(id);
            item.setOrdemServico(os);
            item.setPeca(peca);
            item.setQtd(qtd);
            item.setPreco(peca.getPreco());
        }

        return osPecaRepo.save(item);
    }

    @Transactional
    public void removerPeca(Integer osId, Integer pecaId, String motivo) {
        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        OrdemServicoPecaId id = new OrdemServicoPecaId();
        id.setOrdemServicoCodigo(osId);
        id.setPecaCodigo(pecaId);

        OrdemServicoPeca item = osPecaRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Peça não encontrada nesta Ordem de Serviço."));

        Peca peca = item.getPeca();
        peca.setEstoque(peca.getEstoque() + item.getQtd());
        pecaRepo.save(peca);

        osPecaRepo.delete(item);

        String descricaoLog = "Peça '" + peca.getNome() + "' (" + item.getQtd() + " un.) removida da O.S. #" + osId
                + " e devolvida ao estoque.";
        auditoriaService.registrarExclusao("ordens_servico_pecas", "EXCLUSAO_PECA_OS", descricaoLog, motivoValidado);
    }

    @Transactional
    public OrdemServicoServico adicionarServico(Integer osId, Integer servicoId, Integer qtd) {
        if (qtd == null || qtd <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }
        OrdemServico os = osRepo.findById(osId)
                .orElseThrow(() -> new IllegalArgumentException("Ordem de Serviço #" + osId + " não encontrada."));
        Servico servico = servicoRepo.findById(servicoId)
                .orElseThrow(() -> new IllegalArgumentException("Serviço #" + servicoId + " não encontrado."));

        OrdemServicoServicoId id = new OrdemServicoServicoId();
        id.setOrdemServicoCodigo(osId);
        id.setServicoCodigo(servicoId);

        Optional<OrdemServicoServico> existenteOpt = osServicoRepo.findById(id);
        OrdemServicoServico item;
        if (existenteOpt.isPresent()) {
            item = existenteOpt.get();
            item.setQtd(item.getQtd() + qtd);
            item.setPreco(servico.getPreco());
        } else {
            item = new OrdemServicoServico();
            item.setId(id);
            item.setOrdemServico(os);
            item.setServico(servico);
            item.setQtd(qtd);
            item.setPreco(servico.getPreco());
        }

        return osServicoRepo.save(item);
    }

    @Transactional
    public void removerServico(Integer osId, Integer servicoId, String motivo) {
        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);

        OrdemServicoServicoId id = new OrdemServicoServicoId();
        id.setOrdemServicoCodigo(osId);
        id.setServicoCodigo(servicoId);

        OrdemServicoServico item = osServicoRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Serviço não encontrado nesta Ordem de Serviço."));

        String nomeServico = item.getServico() != null ? item.getServico().getDescricao() : ("#" + servicoId);
        osServicoRepo.delete(item);

        String descricaoLog = "Serviço '" + nomeServico + "' (Qtd: " + item.getQtd() + ") removido da O.S. #" + osId
                + ".";
        auditoriaService.registrarExclusao("ordens_servico_servicos", "EXCLUSAO_SERVICO_OS", descricaoLog,
                motivoValidado);
    }

    public BigDecimal calcularTotal(Integer osId) {
        BigDecimal totalPecas = listarPecas(osId).stream()
                .map(p -> p.getPreco().multiply(new BigDecimal(p.getQtd())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalServicos = listarServicos(osId).stream()
                .map(s -> s.getPreco().multiply(new BigDecimal(s.getQtd())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return totalPecas.add(totalServicos);
    }
}
