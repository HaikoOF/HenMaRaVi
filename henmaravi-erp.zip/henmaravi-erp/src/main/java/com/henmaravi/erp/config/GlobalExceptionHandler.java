package com.henmaravi.erp.config;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleIllegalArgument(IllegalArgumentException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message", ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Map<String, String>> handleTypeMismatch(MethodArgumentTypeMismatchException ex) {
        String param = ex.getName();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message", "Parâmetro inválido ('" + param + "'). Recarregue a página e tente novamente."));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, String>> handleNotReadable(HttpMessageNotReadableException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message", "Os dados enviados no formulário estão em formato inválido. Verifique os campos numéricos e tente novamente."));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, String>> handleDataIntegrity(DataIntegrityViolationException ex) {
        String raw = ex.getMostSpecificCause() != null ? ex.getMostSpecificCause().getMessage() : ex.getMessage();
        String msg = traduzirErroBancoDados(raw);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message", msg));
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, String>> handleRuntime(RuntimeException ex) {
        String raw = ex.getMessage() != null ? ex.getMessage() : "Erro inesperado ao processar a solicitação.";
        if (raw.contains("REFERENCE") || raw.contains("UNIQUE") || raw.contains("FOREIGN KEY") || raw.contains("conflitou")) {
            raw = traduzirErroBancoDados(raw);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message", raw));
    }

    public static String traduzirErroBancoDados(String raw) {
        if (raw == null) {
            return "Operação bloqueada pelas regras de integridade do banco de dados.";
        }
        String lower = raw.toLowerCase();

        // 1. Conflitos de Exclusão (Chave Estrangeira / Integridade Referencial)
        if (lower.contains("delete") && (lower.contains("reference") || lower.contains("foreign key"))) {
            if (lower.contains("veiculos_codigo")) {
                return "Não é possível excluir este veículo porque ele está vinculado a uma ou mais Ordens de Serviço. Exclua a O.S. vinculada ou marque a opção 'Forçar exclusão removendo vínculos'.";
            }
            if (lower.contains("clientes_codigo")) {
                return "Não é possível excluir este cliente porque ele possui Ordens de Serviço registradas em seu nome. Exclua a O.S. vinculada ou marque a opção 'Forçar exclusão removendo vínculos'.";
            }
            if (lower.contains("mecanicos_codigo")) {
                return "Não é possível excluir este mecânico porque ele está vinculado a Ordens de Serviço. Exclua a O.S. vinculada ou marque a opção 'Forçar exclusão removendo vínculos'.";
            }
            if (lower.contains("funcionarios_codigo")) {
                return "Não é possível excluir este funcionário porque ele possui Ordens de Serviço ou Notas de Compra registradas. Marque a opção 'Forçar exclusão removendo vínculos' se desejar remover tudo.";
            }
            if (lower.contains("pecas_codigo")) {
                return "Não é possível excluir esta peça porque ela já foi movimentada em Ordens de Serviço ou Notas de Compra. Marque a opção 'Forçar exclusão removendo vínculos' se desejar remover tudo.";
            }
            if (lower.contains("servicos_codigo")) {
                return "Não é possível excluir este serviço porque ele está vinculado a Ordens de Serviço existentes. Marque a opção 'Forçar exclusão removendo vínculos' se desejar remover tudo.";
            }
            return "Não é possível excluir este registro porque ele está sendo utilizado em outros lançamentos do sistema (Integridade Referencial).";
        }

        // 2. Conflitos de Duplicidade (UNIQUE KEY)
        if (lower.contains("unique") || lower.contains("duplicate") || lower.contains("duplicada")) {
            if (lower.contains("placa")) {
                return "Já existe um veículo cadastrado com esta Placa. Informe uma placa diferente.";
            }
            if (lower.contains("cpf")) {
                return "Já existe um registro cadastrado com este CPF.";
            }
            if (lower.contains("email")) {
                return "Este endereço de e-mail já está em uso por outro cadastro no sistema.";
            }
            if (lower.contains("numero")) {
                return "Já existe uma peça cadastrada com este Código/SKU. Informe outro número de peça.";
            }
            if (lower.contains("username")) {
                return "Este nome de usuário (login) já está em uso. Escolha outro login.";
            }
            return "Já existe um registro com esses mesmos dados únicos (CPF, E-mail, Placa ou Código SKU) no banco de dados.";
        }

        // 3. Truncamento de texto
        if (lower.contains("truncated") || lower.contains("truncados")) {
            return "Um dos campos informados excede o tamanho máximo permitido (verifique se o CPF possui apenas 11 números e o CEP 8 números).";
        }

        return raw;
    }
}

