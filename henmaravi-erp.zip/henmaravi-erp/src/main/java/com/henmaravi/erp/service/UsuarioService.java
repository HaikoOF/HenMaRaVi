package com.henmaravi.erp.service;

import com.henmaravi.erp.entity.Usuario;
import com.henmaravi.erp.repository.UsuarioRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepo;

    @Autowired
    private AuditoriaService auditoriaService;

    @PostConstruct
    public void inicializarUsuariosPadrao() {
        try {
            if (usuarioRepo.findByUsername("admin").isEmpty()) {
                Usuario admin = new Usuario();
                admin.setUsername("admin");
                admin.setPassword("123");
                admin.setNomeCompleto("Administrador Geral");
                admin.setEmail("admin@henmaravi.com");
                admin.setPerfil("ADMIN");
                admin.setDicaSenha("Sequência numérica de 1 a 3");
                admin.setAtivo(true);
                usuarioRepo.save(admin);
            }
            Optional<Usuario> atendenteOpt = usuarioRepo.findByUsername("atendente");
            if (atendenteOpt.isEmpty()) {
                Usuario atendente = new Usuario();
                atendente.setUsername("atendente");
                atendente.setPassword("123");
                atendente.setNomeCompleto("Beatriz Silva (Operacional)");
                atendente.setEmail("beatriz@henmaravi.com");
                atendente.setPerfil("ATENDENTE");
                atendente.setDicaSenha("Sequência numérica de 1 a 3");
                atendente.setAtivo(true);
                usuarioRepo.save(atendente);
            } else {
                Usuario at = atendenteOpt.get();
                if (!"ATENDENTE".equals(at.getPerfil())) {
                    at.setPerfil("ATENDENTE");
                    usuarioRepo.save(at);
                }
            }
            if (usuarioRepo.findByUsername("mecanico").isEmpty()) {
                Usuario mec = new Usuario();
                mec.setUsername("mecanico");
                mec.setPassword("123");
                mec.setNomeCompleto("Kleber Machado (Mecânico)");
                mec.setEmail("mecanico@henmaravi.com");
                mec.setPerfil("MECANICO");
                mec.setDicaSenha("Sequência numérica de 1 a 3");
                mec.setAtivo(true);
                usuarioRepo.save(mec);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario u = usuarioRepo.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado: " + username));

        if (!Boolean.TRUE.equals(u.getAtivo())) {
            throw new UsernameNotFoundException("Usuário inativo: " + username);
        }

        String role = u.getPerfil().startsWith("ROLE_") ? u.getPerfil() : "ROLE_" + u.getPerfil().toUpperCase();
        return new User(
                u.getUsername(),
                u.getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority(role)));
    }

    public Optional<Usuario> buscarPorId(Integer id) {
        return usuarioRepo.findById(id);
    }

    public Optional<Usuario> buscarPorUsername(String username) {
        return usuarioRepo.findByUsername(username);
    }

    public Optional<Usuario> buscarPorUsernameOuEmail(String termo) {
        return usuarioRepo.findByUsernameOrEmail(termo, termo);
    }

    public List<Usuario> listarTodos() {
        return usuarioRepo.findAll();
    }

    @Transactional
    public Usuario salvarContaPeloAdmin(Usuario dados) {
        if (dados.getUsername() == null || dados.getUsername().trim().isEmpty()) {
            throw new IllegalArgumentException("O login (usuário) é obrigatório.");
        }
        dados.setUsername(dados.getUsername().trim());

        if (dados.getNomeCompleto() == null || dados.getNomeCompleto().trim().isEmpty()) {
            throw new IllegalArgumentException("O nome completo do usuário é obrigatório.");
        }
        dados.setNomeCompleto(dados.getNomeCompleto().trim());

        if (dados.getEmail() == null || dados.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("O e-mail do usuário é obrigatório.");
        }
        dados.setEmail(dados.getEmail().trim());

        if (dados.getPerfil() == null || dados.getPerfil().isBlank()) {
            dados.setPerfil("ATENDENTE");
        }

        // Edição de conta existente
        if (dados.getCodigo() != null) {
            Usuario existente = usuarioRepo.findById(dados.getCodigo())
                    .orElseThrow(
                            () -> new IllegalArgumentException("Usuário #" + dados.getCodigo() + " não encontrado."));

            usuarioRepo.findByUsername(dados.getUsername()).ifPresent(u -> {
                if (!u.getCodigo().equals(existente.getCodigo())) {
                    throw new IllegalArgumentException(
                            "Já existe outro usuário utilizando o login '" + dados.getUsername() + "'.");
                }
            });
            usuarioRepo.findByEmail(dados.getEmail()).ifPresent(u -> {
                if (!u.getCodigo().equals(existente.getCodigo())) {
                    throw new IllegalArgumentException(
                            "Já existe outro usuário utilizando o e-mail '" + dados.getEmail() + "'.");
                }
            });

            existente.setUsername(dados.getUsername());
            existente.setNomeCompleto(dados.getNomeCompleto());
            existente.setEmail(dados.getEmail());
            existente.setPerfil(dados.getPerfil());
            existente.setDicaSenha(dados.getDicaSenha());
            if (dados.getAtivo() != null) {
                existente.setAtivo(dados.getAtivo());
            }
            if (dados.getPassword() != null && !dados.getPassword().isBlank()) {
                existente.setPassword(dados.getPassword());
            }
            return usuarioRepo.save(existente);
        }

        // Criação de nova conta
        if (dados.getPassword() == null || dados.getPassword().isBlank()) {
            throw new IllegalArgumentException("Informe uma senha para o novo usuário.");
        }
        if (usuarioRepo.findByUsername(dados.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Já existe um usuário com o login '" + dados.getUsername() + "'.");
        }
        if (usuarioRepo.findByEmail(dados.getEmail()).isPresent()) {
            throw new IllegalArgumentException(
                    "Já existe um usuário cadastrado com o e-mail '" + dados.getEmail() + "'.");
        }

        dados.setAtivo(true);
        return usuarioRepo.save(dados);
    }

    @Transactional
    public void excluir(Integer id, String motivo) {
        Usuario u = usuarioRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Usuário #" + id + " não encontrado."));

        if ("admin".equalsIgnoreCase(u.getUsername())) {
            throw new IllegalArgumentException("A conta principal 'admin' não pode ser excluída do sistema.");
        }

        String motivoValidado = auditoriaService.validarMotivoObrigatorio(motivo);
        String descricao = "Conta de Usuário #" + u.getCodigo() + " - Login: " + u.getUsername() + " ("
                + u.getNomeCompleto() + ", Perfil: " + u.getPerfil() + ")";

        usuarioRepo.deleteById(id);
        auditoriaService.registrarExclusao("usuarios", "EXCLUSAO_USUARIO", descricao, motivoValidado);
    }

    @Transactional
    public Usuario atualizarPerfil(String usernameAtual, String nomeCompleto, String email, String novaSenha,
            String dicaSenha) {
        Usuario u = usuarioRepo.findByUsername(usernameAtual)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado."));

        usuarioRepo.findByEmail(email).ifPresent(outro -> {
            if (!outro.getCodigo().equals(u.getCodigo())) {
                throw new IllegalArgumentException("Este e-mail já está sendo utilizado por outro usuário.");
            }
        });

        u.setNomeCompleto(nomeCompleto);
        u.setEmail(email);
        u.setDicaSenha(dicaSenha);
        if (novaSenha != null && !novaSenha.isBlank()) {
            u.setPassword(novaSenha);
        }
        return usuarioRepo.save(u);
    }

    @Transactional
    public void redefinirSenha(String usernameOuEmail, String emailConfirmacao, String novaSenha) {
        Usuario u = usuarioRepo.findByUsernameOrEmail(usernameOuEmail, usernameOuEmail)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não localizado na base de dados."));
        if (!u.getEmail().equalsIgnoreCase(emailConfirmacao)) {
            throw new IllegalArgumentException("O e-mail de confirmação não confere com o cadastro.");
        }
        u.setPassword(novaSenha);
        usuarioRepo.save(u);
    }
}
