package com.henmaravi.erp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@Entity
@Table(name = "mecanicos")
@PrimaryKeyJoinColumn(name = "pessoas_codigo")
@Data
@EqualsAndHashCode(callSuper = true)
public class Mecanico extends Pessoa {

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal comissao;
}
