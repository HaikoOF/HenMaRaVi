package com.henmaravi.erp.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "ordens_servico_servicos")
@Data
public class OrdemServicoServico {

    @EmbeddedId
    private OrdemServicoServicoId id = new OrdemServicoServicoId();

    @ManyToOne(optional = false)
    @MapsId("ordemServicoCodigo")
    @JoinColumn(name = "ordens_servico_codigo", nullable = false)
    private OrdemServico ordemServico;

    @ManyToOne(optional = false)
    @MapsId("servicoCodigo")
    @JoinColumn(name = "servicos_codigo", nullable = false)
    private Servico servico;

    @Column(nullable = false, columnDefinition = "int default 1")
    private Integer qtd;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal preco;

    // Getter auxiliar para serialização JSON no front-end (evita undefined em s.servicoCodigo)
    public Integer getServicoCodigo() {
        if (servico != null && servico.getCodigo() != null) {
            return servico.getCodigo();
        }
        return id != null ? id.getServicoCodigo() : null;
    }
}
