/**
 * API Utils
 * Wrapper para a Fetch API, simplificando chamadas REST,
 * injetando tokens de sessão/CSRF e tratando erros globais com mensagens amigáveis.
 */

const Api = {
    baseUrl: '/api',

    async request(endpoint, method = 'GET', data = null) {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        const csrfToken = document.querySelector('meta[name="_csrf"]')?.content;
        const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.content;
        if (csrfToken && csrfHeader) {
            headers[csrfHeader] = csrfToken;
        }

        const config = {
            method,
            headers,
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
            config.body = JSON.stringify(data);
        }

        try {
            if (window.UI) UI.showLoading();

            const response = await fetch(`${this.baseUrl}${endpoint}`, config);

            if (window.UI) UI.hideLoading();

            if (!response.ok) {
                if (response.status === 401) {
                    window.location.href = '/login';
                    throw new Error('Sua sessão expirou. Por favor, faça login novamente.');
                }
                if (response.status === 403) {
                    throw new Error('Acesso negado: o seu perfil de usuário não possui permissão para realizar esta operação.');
                }

                const errorData = await response.json().catch(() => ({}));
                const friendlyMsg = errorData.message || errorData.error || `Não foi possível concluir a operação (Código ${response.status}).`;
                throw new Error(friendlyMsg);
            }

            if (response.status === 204) return null;

            return await response.json();

        } catch (error) {
            if (window.UI) {
                UI.hideLoading();
                UI.showToast('Não foi possível concluir a ação', error.message, 'danger');
            }
            console.error('[API Error]', error);
            throw error;
        }
    },

    get(endpoint) { return this.request(endpoint, 'GET'); },
    post(endpoint, data) { return this.request(endpoint, 'POST', data); },
    put(endpoint, data) { return this.request(endpoint, 'PUT', data); },
    delete(endpoint, params = null) {
        let url = endpoint;
        if (params && typeof params === 'object') {
            const qs = new URLSearchParams();
            if (params.motivo !== undefined && params.motivo !== null) {
                qs.append('motivo', params.motivo);
            }
            if (params.forcar !== undefined && params.forcar !== null) {
                qs.append('forcar', params.forcar);
            }
            const queryStr = qs.toString();
            if (queryStr) {
                url += (url.includes('?') ? '&' : '?') + queryStr;
            }
        }
        return this.request(url, 'DELETE');
    }
};

window.Api = Api;
