/**
 * API Utils
 * Wrapper para a Fetch API, simplificando chamadas REST,
 * injetando tokens de sessão/CSRF e tratando erros globais.
 */

const Api = {
    // Base URL da API (pode ser ajustado conforme ambiente)
    baseUrl: '/api',

    /**
     * Realiza uma requisição HTTP genérica
     */
    async request(endpoint, method = 'GET', data = null) {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        const csrfToken = document.querySelector('meta[name="_csrf"]')?.content;
        const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.content;
        if (csrfToken && csrfHeader) {
            headers[csrfHeader] = csrfToken;
        }

        const config = {
            method,
            headers,
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
            config.body = JSON.stringify(data);
        }

        try {
            // Mostrar loading overlay se estiver usando a biblioteca UI
            if (window.UI) UI.showLoading();

            const response = await fetch(`${this.baseUrl}${endpoint}`, config);
            
            if (window.UI) UI.hideLoading();

            if (!response.ok) {
                // Tratar erros HTTP
                if (response.status === 401) {
                    window.location.href = '/login'; // Redirecionar se não autenticado
                    throw new Error('Sessão expirada. Por favor, faça login novamente.');
                }
                
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `Erro HTTP: ${response.status}`);
            }

            // Para requisições DELETE (204 No Content) que não retornam JSON
            if (response.status === 204) return null;

            return await response.json();

        } catch (error) {
            if (window.UI) {
                UI.hideLoading();
                UI.showToast('Erro de Comunicação', error.message, 'danger');
            }
            console.error('[API Error]', error);
            throw error;
        }
    },

    get(endpoint) { return this.request(endpoint, 'GET'); },
    post(endpoint, data) { return this.request(endpoint, 'POST', data); },
    put(endpoint, data) { return this.request(endpoint, 'PUT', data); },
    delete(endpoint) { return this.request(endpoint, 'DELETE'); }
};

window.Api = Api;
