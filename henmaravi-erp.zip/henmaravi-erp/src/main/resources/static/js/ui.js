/**
 * UI Utils
 * Controla os componentes visuais: Sidebar, Toasts, Loaders e Modais (incluindo Modal Global de Exclusão com Motivo).
 */

const UI = {
    init() {
        this.initSidebar();
        this.initToastContainer();
        this.initDeleteModal();
    },

    initSidebar() {
        const toggleBtn = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', () => {
                if (window.innerWidth <= 991.98) {
                    sidebar.classList.toggle('mobile-open');
                    if (overlay) overlay.classList.toggle('active');
                } else {
                    sidebar.classList.toggle('collapsed');
                }
            });
        }

        if (overlay) {
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');
            });
        }
    },

    initToastContainer() {
        if (!document.getElementById('toastContainer')) {
            const container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'toast-container position-fixed top-0 end-0 p-3';
            container.style.zIndex = '1090';
            document.body.appendChild(container);
        }
    },

    showToast(title, message, type = 'primary') {
        this.initToastContainer();
        const container = document.getElementById('toastContainer');
        if (!container) return;

        const toastId = 'toast-' + Date.now();
        const icon = type === 'success' ? 'check-circle-fill' : type === 'danger' ? 'exclamation-octagon-fill' : type === 'warning' ? 'exclamation-triangle-fill' : 'info-circle-fill';

        const toastHtml = `
            <div id="${toastId}" class="toast shadow" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header text-white bg-${type}">
                    <i class="bi bi-${icon} me-2"></i>
                    <strong class="me-auto">${title}</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body fw-semibold text-dark bg-white">
                    ${message}
                </div>
            </div>
        `;

        container.insertAdjacentHTML('beforeend', toastHtml);
        const toastEl = document.getElementById(toastId);

        const delayMs = type === 'danger' ? 7000 : 4000;
        const bsToast = new bootstrap.Toast(toastEl, { delay: delayMs });
        bsToast.show();

        toastEl.addEventListener('hidden.bs.toast', () => {
            toastEl.remove();
        });
    },

    /**
     * Modal Global para Exclusão com Motivo Obrigatório e Auditoria de Usuário Logado
     */
    initDeleteModal() {
        if (document.getElementById('globalDeleteModal')) return;

        const modalHtml = `
            <div class="modal fade" id="globalDeleteModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow-lg">
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title fw-bold" id="globalDeleteTitle">
                                <i class="bi bi-trash3-fill me-2"></i>Confirmar Exclusão
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p class="mb-2 text-dark" id="globalDeleteDescription">Tem certeza que deseja excluir este registro?</p>
                            
                            <div class="alert alert-light border small py-2 mb-3">
                                <i class="bi bi-person-check-fill text-primary me-1"></i>
                                <strong>Responsável (Logado):</strong>
                                <span id="globalDeleteUser">Usuário Autenticado</span>
                            </div>

                            <div class="mb-3">
                                <label for="globalDeleteMotivo" class="form-label small fw-bold text-danger mb-1">
                                    MOTIVO DA EXCLUSÃO (OBRIGATÓRIO PARA O LOG) *
                                </label>
                                <textarea id="globalDeleteMotivo" class="form-control" rows="2"
                                          placeholder="Informe o motivo pelo qual está apagando este registro..." required></textarea>
                                <div class="invalid-feedback">
                                    Você precisa informar o motivo da exclusão para continuar.
                                </div>
                            </div>

                            <div class="form-check p-3 bg-warning bg-opacity-10 border border-warning rounded" id="globalDeleteCascadeWrapper" style="display: none;">
                                <input class="form-check-input ms-0 me-2" type="checkbox" id="globalDeleteCascade">
                                <label class="form-check-label small text-dark" for="globalDeleteCascade">
                                    <strong>Forçar exclusão removendo vínculos dependentes</strong><br>
                                    <span class="text-muted">Se marcado, exclui também Ordens de Serviço ou itens vinculados a este registro. Se desmarcado, o banco protegerá registros que já possuem histórico.</span>
                                </label>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancelar</button>
                            <button type="button" class="btn btn-danger fw-bold px-4" id="globalDeleteConfirmBtn">
                                <i class="bi bi-trash me-1"></i> Confirmar e Registrar Log
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    },

    confirmDelete({ title = 'Confirmar Exclusão', description = 'Deseja realmente apagar este registro?', allowCascade = false, onConfirm }) {
        this.initDeleteModal();
        const modalEl = document.getElementById('globalDeleteModal');
        const titleEl = document.getElementById('globalDeleteTitle');
        const descEl = document.getElementById('globalDeleteDescription');
        const userEl = document.getElementById('globalDeleteUser');
        const motivoInput = document.getElementById('globalDeleteMotivo');
        const cascadeWrapper = document.getElementById('globalDeleteCascadeWrapper');
        const cascadeCheckbox = document.getElementById('globalDeleteCascade');
        const confirmBtn = document.getElementById('globalDeleteConfirmBtn');

        titleEl.innerHTML = `<i class="bi bi-trash3-fill me-2"></i>${title}`;
        descEl.innerText = description;

        const headerUserName = document.querySelector('.header-user-profile .fw-semibold')?.innerText || 'Usuário Logado';
        const headerUserRole = document.querySelector('.header-user-profile small')?.innerText || '';
        userEl.innerText = headerUserRole ? `${headerUserName} (${headerUserRole})` : headerUserName;

        motivoInput.value = '';
        motivoInput.classList.remove('is-invalid');
        cascadeCheckbox.checked = false;
        cascadeWrapper.style.display = allowCascade ? 'block' : 'none';

        const bsModal = bootstrap.Modal.getOrCreateInstance(modalEl);

        // Substituir listener do botão confirmar
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

        newConfirmBtn.addEventListener('click', async () => {
            const motivo = motivoInput.value.trim();
            if (!motivo) {
                motivoInput.classList.add('is-invalid');
                motivoInput.focus();
                return;
            }
            motivoInput.classList.remove('is-invalid');
            const forcar = cascadeCheckbox.checked;
            bsModal.hide();
            if (typeof onConfirm === 'function') {
                await onConfirm(motivo, forcar);
            }
        });

        bsModal.show();
        setTimeout(() => motivoInput.focus(), 300);
    },

    showLoading(text = 'Carregando...') {
        let overlay = document.getElementById('globalLoading');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'globalLoading';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = `
                <div class="spinner"></div>
                <div class="loading-text">${text}</div>
            `;
            document.body.appendChild(overlay);
        } else {
            overlay.querySelector('.loading-text').innerText = text;
        }
        setTimeout(() => overlay.classList.add('active'), 10);
    },

    hideLoading() {
        const overlay = document.getElementById('globalLoading');
        if (overlay) {
            overlay.classList.remove('active');
            setTimeout(() => {
                if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
            }, 300);
        }
    }
};

window.UI = UI;
