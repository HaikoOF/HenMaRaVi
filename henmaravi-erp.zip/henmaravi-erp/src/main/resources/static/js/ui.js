/**
 * UI Utils
 * Controla os componentes visuais: Sidebar, Toasts, Loaders e Modais.
 */

const UI = {
    /**
     * Inicializa os comportamentos base da interface
     */
    init() {
        this.initSidebar();
        this.initToastContainer();
    },

    /**
     * Lógica para abrir/fechar a Sidebar
     */
    initSidebar() {
        const toggleBtn = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', () => {
                if (window.innerWidth <= 991.98) {
                    sidebar.classList.toggle('mobile-open');
                    if (overlay) overlay.classList.toggle('active');
                } else {
                    sidebar.classList.toggle('collapsed');
                }
            });
        }

        if (overlay) {
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');
            });
        }
    },

    /**
     * Gerenciamento de Toasts (Notificações)
     */
    initToastContainer() {
        if (!document.getElementById('toastContainer')) {
            const container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'toast-container p-3';
            document.body.appendChild(container);
        }
    },

    showToast(title, message, type = 'primary') {
        const container = document.getElementById('toastContainer');
        if (!container) return;

        // type: primary, success, danger, warning, info
        const toastId = 'toast-' + Date.now();
        const icon = type === 'success' ? 'check-circle' : type === 'danger' ? 'x-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle';

        const toastHtml = `
            <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header text-white bg-${type}">
                    <i class="bi bi-${icon} me-2"></i>
                    <strong class="me-auto">${title}</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', toastHtml);
        const toastEl = document.getElementById(toastId);
        
        // Utilizando a API nativa do Bootstrap 5
        const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
        bsToast.show();

        // Limpar do DOM após fechar
        toastEl.addEventListener('hidden.bs.toast', () => {
            toastEl.remove();
        });
    },

    /**
     * Loading Overlay
     */
    showLoading(text = 'Carregando...') {
        let overlay = document.getElementById('globalLoading');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'globalLoading';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = `
                <div class="spinner"></div>
                <div class="loading-text">${text}</div>
            `;
            document.body.appendChild(overlay);
        } else {
            overlay.querySelector('.loading-text').innerText = text;
        }
        
        // Pequeno delay para permitir a renderização do navegador
        setTimeout(() => overlay.classList.add('active'), 10);
    },

    hideLoading() {
        const overlay = document.getElementById('globalLoading');
        if (overlay) {
            overlay.classList.remove('active');
            // Aguardar a transição antes de remover
            setTimeout(() => {
                if(overlay.parentNode) overlay.parentNode.removeChild(overlay);
            }, 300);
        }
    }
};

window.UI = UI;
