/**
 * Main Entry Point
 * Inicializa a aplicação e registra listeners globais após o carregamento do DOM.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar componentes visuais base
    UI.init();

    // Marcar item ativo no menu da sidebar baseado na URL atual
    const currentPath = window.location.pathname;
    const menuLinks = document.querySelectorAll('.sidebar-menu a');
    
    menuLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        // Uma checagem simples, pode ser aprimorada
        if (linkPath && linkPath !== '#' && currentPath.startsWith(linkPath)) {
            link.classList.add('active');
        }
    });

    // Exemplo de uso de Tooltips Globais do Bootstrap se necessário
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
});
