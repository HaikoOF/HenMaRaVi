package com.henmaravi.erp;

import com.henmaravi.erp.entity.*;
import com.henmaravi.erp.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class CrudAndRulesIntegrationTest {

    @Autowired
    private ClienteService clienteService;
    @Autowired
    private FuncionarioService funcionarioService;
    @Autowired
    private MecanicoService mecanicoService;
    @Autowired
    private VeiculoService veiculoService;
    @Autowired
    private PecaService pecaService;
    @Autowired
    private CompraService compraService;
    @Autowired
    private AuditoriaService auditoriaService;

    @BeforeEach
    void configurarUsuarioLogado() {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(
                        "admin", "123", List.of(new SimpleGrantedAuthority("ROLE_ADMIN"))));
    }

    @Test
    void testarFluxoCompletoEdicaoExclusaoReusoPessoaEEstoque() {
        // 1. Testar Item 8: Mecânico que já existe no banco (#21, CPF 32132132111)
        // virando Cliente (reuso de Pessoa)
        Mecanico mec21 = mecanicoService.buscarPorId(21).orElseThrow();
        assertEquals("32132132111", mec21.getCpf());

        Cliente novoCliReusandoPessoa = new Cliente();
        novoCliReusandoPessoa.setNome(mec21.getNome());
        novoCliReusandoPessoa.setCpf("321.321.321-11"); // Com máscara para testar normalização também
        novoCliReusandoPessoa.setTelefone(mec21.getTelefone());
        novoCliReusandoPessoa.setEmail(mec21.getEmail());

        Cliente clienteCriado = clienteService.salvar(novoCliReusandoPessoa);
        assertEquals(21, clienteCriado.getCodigo(), "Deve reutilizar o mesmo código (PK) da tabela pessoas!");

        // Excluir o papel de Cliente do ID 21 e garantir que ele continua existindo
        // como Mecânico!
        clienteService.excluir(21, "Teste de desvinculação apenas da tabela clientes", false);
        assertTrue(mecanicoService.buscarPorId(21).isPresent(),
                "O registro em mecanicos e pessoas deve permanecer intacto!");

        // 2. Testar Item 2: Edição real de Funcionário, Mecânico e Veículo preservando
        // todos os campos
        Funcionario func11 = funcionarioService.buscarPorId(11).orElseThrow();
        String emailOriginal = func11.getEmail();
        func11.setSalario(new BigDecimal("5200.00"));
        funcionarioService.salvar(func11);
        Funcionario func11Atualizado = funcionarioService.buscarPorId(11).orElseThrow();
        assertEquals(new BigDecimal("5200.00"), func11Atualizado.getSalario());
        assertEquals(emailOriginal, func11Atualizado.getEmail());

        // 3. Testar Item 3 & 4: Exclusão de veículo criado pelo banco (com forcar=false
        // deve dar mensagem amigável; com forcar=true apaga)
        IllegalArgumentException erroEsperado = assertThrows(IllegalArgumentException.class,
                () -> veiculoService.excluir(1, "Tentativa sem forçar", false));
        assertTrue(erroEsperado.getMessage().contains("Ordem(ns) de Serviço #1"),
                "Mensagem amigável deve citar a O.S. vinculada");

        // Com forcar=true, deve apagar o veículo #10 do banco de dados junto com seus
        // vínculos
        veiculoService.excluir(10, "Veículo vendido / baixa de frota", true);
        assertTrue(veiculoService.buscarPorId(10).isEmpty(), "Veículo #10 do banco deve ter sido excluído!");

        // 4. Testar Item 5 e 6: Remover produto da entrada de estoque e excluir Compra
        // subtraindo estoque e gerando Log
        Peca peca1Antes = pecaService.buscarPorId(1).orElseThrow();
        int estoqueInicial = peca1Antes.getEstoque();

        List<PecaCompra> itensCompra8 = compraService.listarPecas(8);
        assertFalse(itensCompra8.isEmpty());
        assertEquals(1, itensCompra8.get(0).getPecaCodigo(), "getPecaCodigo() nunca deve ser null/undefined");

        // Remove 2 unidades da peça #1 que estavam na Compra #8
        compraService.removerPeca(8, 1, "Devolução parcial ao fornecedor");
        Peca peca1AposRemoverItem = pecaService.buscarPorId(1).orElseThrow();
        assertEquals(estoqueInicial - 2, peca1AposRemoverItem.getEstoque(), "Estoque deve diminuir em 2 unidades!");

        // Exclui a Compra #1 inteira (que tinha 10 unidades da peça #1)
        compraService.excluir(1, "Cancelamento da Nota Fiscal #1");
        Peca peca1AposExcluirCompra = pecaService.buscarPorId(1).orElseThrow();
        assertEquals(estoqueInicial - 12, peca1AposExcluirCompra.getEstoque(),
                "Estoque deve diminuir mais 10 unidades ao excluir a Compra #1!");

        // 5. Testar Item 7: Verificar se todas as exclusões deixaram quem apagou
        // (admin) e o motivo nos Logs
        List<LogAuditoria> logsExclusao = auditoriaService.listarLogsExclusao();
        assertFalse(logsExclusao.isEmpty());
        LogAuditoria ultimoLog = logsExclusao.get(0);
        assertNotNull(ultimoLog.getUsuarioResponsavel());
        assertTrue(ultimoLog.getUsuarioResponsavel().contains("admin"));
        assertEquals("Cancelamento da Nota Fiscal #1", ultimoLog.getMotivo());
    }
}
