document.addEventListener("DOMContentLoaded", () => {
    initCharts();
    loadRecentActivities();
});

function initCharts() {
    // Faturamento Chart (Line)
    const ctxFaturamento = document.getElementById('chartFaturamento');
    if (ctxFaturamento) {
        new Chart(ctxFaturamento, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul'],
                datasets: [{
                    label: 'Faturamento (R$)',
                    data: [12500, 15000, 14200, 18500, 17000, 21000, 25000],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value;
                            }
                        }
                    }
                }
            }
        });
    }

    // OS Status Chart (Doughnut)
    const ctxOsStatus = document.getElementById('chartOsStatus');
    if (ctxOsStatus) {
        new Chart(ctxOsStatus, {
            type: 'doughnut',
            data: {
                labels: ['Abertas', 'Em Andamento', 'Aguardando Peças', 'Concluídas'],
                datasets: [{
                    data: [15, 20, 5, 45],
                    backgroundColor: [
                        '#0dcaf0', // Info
                        '#ffc107', // Warning
                        '#dc3545', // Danger
                        '#198754'  // Success
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
}

function loadRecentActivities() {
    // Simulate API Call for Recent OS
    const tbody = document.getElementById('recentOsTableBody');
    if (!tbody) return;

    const mockData = [
        { os: 'OS-1024', cliente: 'João Silva', veiculo: 'Honda Civic 2020', status: 'Em Andamento', valor: 850.00, data: '2023-10-25' },
        { os: 'OS-1025', cliente: 'Maria Oliveira', veiculo: 'Toyota Corolla 2018', status: 'Aberta', valor: 0.00, data: '2023-10-26' },
        { os: 'OS-1026', cliente: 'Carlos Santos', veiculo: 'VW Gol 2015', status: 'Concluída', valor: 350.00, data: '2023-10-26' },
        { os: 'OS-1027', cliente: 'Empresa XYZ', veiculo: 'Fiat Fiorino 2021', status: 'Aberta', valor: 0.00, data: '2023-10-27' },
        { os: 'OS-1028', cliente: 'Ana Costa', veiculo: 'Jeep Compass 2022', status: 'Concluída', valor: 1200.00, data: '2023-10-27' }
    ];

    let html = '';
    mockData.forEach(item => {
        let badgeClass = '';
        let statusLabel = item.status;
        
        switch(item.status) {
            case 'Aberta': badgeClass = 'badge-status-aberta'; break;
            case 'Em Andamento': badgeClass = 'badge-status-andamento'; break;
            case 'Concluída': badgeClass = 'badge-status-concluida'; break;
            default: badgeClass = 'bg-secondary text-white rounded px-2 py-1'; break;
        }

        html += `
            <tr>
                <td><strong>#${item.os}</strong></td>
                <td>${item.cliente}</td>
                <td>${item.veiculo}</td>
                <td><span class="${badgeClass}">${statusLabel}</span></td>
                <td>${formatCurrency(item.valor)}</td>
                <td>${formatDate(item.data)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="Ver Detalhes">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
    
    // Reinitialize tooltips for dynamically added elements
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    });
}
