﻿SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO
USE HenmaraviDB;
GO

-- =================================================================================
-- 1. CRIAÇÃO DAS TABELAS (DDL - SCHEMA COMPLETO COM INTEGRIDADE REFERENCIAL)
-- =================================================================================

-- 1.1 TABELA DE USUÁRIOS DO SISTEMA (AUTENTICAÇÃO E PERFIS DE ACESSO)
IF OBJECT_ID('dbo.usuarios', 'U') IS NULL
BEGIN
    CREATE TABLE usuarios (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        nome_completo VARCHAR(150) NOT NULL,
        email VARCHAR(320) NOT NULL UNIQUE,
        perfil VARCHAR(30) NOT NULL DEFAULT 'MECANICO', -- 'ADMIN' ou 'MECANICO'
        dica_senha VARCHAR(255),
        ativo BIT NOT NULL DEFAULT 1
    );
END
GO

-- 1.2 TABELA DE LOGS DE AUDITORIA (ALIMENTADA POR EXCLUSÕES, TRIGGERS E PROCEDURES)
IF OBJECT_ID('dbo.logs_auditoria', 'U') IS NULL
BEGIN
    CREATE TABLE logs_auditoria (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        data_evento DATETIME DEFAULT GETDATE(),
        usuario_responsavel VARCHAR(100) DEFAULT 'Sistema/SQL',
        motivo VARCHAR(500),
        tabela_afetada VARCHAR(100) NOT NULL,
        acao VARCHAR(50) NOT NULL,
        descricao VARCHAR(500) NOT NULL
    );
END
ELSE
BEGIN
    IF COL_LENGTH('dbo.logs_auditoria', 'usuario_responsavel') IS NULL
        ALTER TABLE dbo.logs_auditoria ADD usuario_responsavel VARCHAR(100) DEFAULT 'Sistema/SQL';
    IF COL_LENGTH('dbo.logs_auditoria', 'motivo') IS NULL
        ALTER TABLE dbo.logs_auditoria ADD motivo VARCHAR(500);
END
GO

-- 1.3 TABELA PAI (HERANÇA JPA - JOINED)
IF OBJECT_ID('dbo.pessoas', 'U') IS NULL
BEGIN
    CREATE TABLE pessoas (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        nome VARCHAR(150) NOT NULL,
        cpf VARCHAR(11) NOT NULL UNIQUE,
        cep VARCHAR(8),
        email VARCHAR(320) UNIQUE,
        telefone VARCHAR(20)
    );
END
GO

-- 1.4 TABELAS FILHAS (HERANÇA)
IF OBJECT_ID('dbo.clientes', 'U') IS NULL
BEGIN
    CREATE TABLE clientes (
        pessoas_codigo INT PRIMARY KEY,
        FOREIGN KEY (pessoas_codigo) REFERENCES pessoas(codigo)
    );
END
GO

IF OBJECT_ID('dbo.funcionarios', 'U') IS NULL
BEGIN
    CREATE TABLE funcionarios (
        pessoas_codigo INT PRIMARY KEY,
        salario DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (pessoas_codigo) REFERENCES pessoas(codigo)
    );
END
GO

IF OBJECT_ID('dbo.mecanicos', 'U') IS NULL
BEGIN
    CREATE TABLE mecanicos (
        pessoas_codigo INT PRIMARY KEY,
        comissao DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (pessoas_codigo) REFERENCES pessoas(codigo)
    );
END
GO

-- 1.5 TABELAS BASE (CATÁLOGO E FROTA)
IF OBJECT_ID('dbo.veiculos', 'U') IS NULL
BEGIN
    CREATE TABLE veiculos (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        placa VARCHAR(7) NOT NULL UNIQUE,
        descricao VARCHAR(255) NOT NULL,
        preco DECIMAL(10,2) NOT NULL
    );
END
GO

IF OBJECT_ID('dbo.pecas', 'U') IS NULL
BEGIN
    CREATE TABLE pecas (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        numero VARCHAR(50) NOT NULL UNIQUE,
        nome VARCHAR(100) NOT NULL,
        descricao VARCHAR(255),
        preco DECIMAL(10,2) NOT NULL,
        estoque INT NOT NULL DEFAULT 0
    );
END
GO

IF OBJECT_ID('dbo.servicos', 'U') IS NULL
BEGIN
    CREATE TABLE servicos (
        codigo_servico INT IDENTITY(1,1) PRIMARY KEY,
        descricao VARCHAR(100) NOT NULL,
        preco DECIMAL(10,2) NOT NULL
    );
END
GO

-- 1.6 TABELAS TRANSACIONAIS E RELACIONAMENTOS N x N
IF OBJECT_ID('dbo.compras', 'U') IS NULL
BEGIN
    CREATE TABLE compras (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        data_compra DATETIME DEFAULT GETDATE(),
        valor_total DECIMAL(10,2) NOT NULL,
        funcionarios_codigo INT NOT NULL,
        FOREIGN KEY (funcionarios_codigo) REFERENCES funcionarios(pessoas_codigo)
    );
END
GO

-- Relacionamento N x N entre Compras e Peças
IF OBJECT_ID('dbo.pecas_compras', 'U') IS NULL
BEGIN
    CREATE TABLE pecas_compras (
        compras_codigo INT NOT NULL,
        pecas_codigo INT NOT NULL,
        preco_unitario DECIMAL(10,2) NOT NULL,
        qtd INT NOT NULL,
        PRIMARY KEY (compras_codigo, pecas_codigo),
        FOREIGN KEY (compras_codigo) REFERENCES compras(codigo),
        FOREIGN KEY (pecas_codigo) REFERENCES pecas(codigo)
    );
END
GO

IF OBJECT_ID('dbo.ordens_servico', 'U') IS NULL
BEGIN
    CREATE TABLE ordens_servico (
        codigo INT IDENTITY(1,1) PRIMARY KEY,
        data_abretura DATETIME DEFAULT GETDATE(),
        status VARCHAR(50) NOT NULL DEFAULT 'Aberta',
        clientes_codigo INT NOT NULL,
        funcionarios_codigo INT NOT NULL,
        mecanicos_codigo INT NOT NULL,
        veiculos_codigo INT NOT NULL,
        FOREIGN KEY (clientes_codigo) REFERENCES clientes(pessoas_codigo),
        FOREIGN KEY (funcionarios_codigo) REFERENCES funcionarios(pessoas_codigo),
        FOREIGN KEY (mecanicos_codigo) REFERENCES mecanicos(pessoas_codigo),
        FOREIGN KEY (veiculos_codigo) REFERENCES veiculos(codigo)
    );
END
GO

-- Relacionamento N x N entre Ordens de Serviço e Peças
IF OBJECT_ID('dbo.ordens_servico_pecas', 'U') IS NULL
BEGIN
    CREATE TABLE ordens_servico_pecas (
        ordens_servico_codigo INT NOT NULL,
        pecas_codigo INT NOT NULL,
        preco DECIMAL(10,2) NOT NULL,
        qtd INT NOT NULL,
        PRIMARY KEY (ordens_servico_codigo, pecas_codigo),
        FOREIGN KEY (ordens_servico_codigo) REFERENCES ordens_servico(codigo),
        FOREIGN KEY (pecas_codigo) REFERENCES pecas(codigo)
    );
END
GO

-- Relacionamento N x N entre Ordens de Serviço e Serviços
IF OBJECT_ID('dbo.ordens_servico_servicos', 'U') IS NULL
BEGIN
    CREATE TABLE ordens_servico_servicos (
        ordens_servico_codigo INT NOT NULL,
        servicos_codigo INT NOT NULL,
        preco DECIMAL(10,2) NOT NULL,
        qtd INT NOT NULL DEFAULT 1,
        PRIMARY KEY (ordens_servico_codigo, servicos_codigo),
        FOREIGN KEY (ordens_servico_codigo) REFERENCES ordens_servico(codigo),
        FOREIGN KEY (servicos_codigo) REFERENCES servicos(codigo_servico)
    );
END
GO


-- =================================================================================
-- 2. INSERÇÃO DOS DADOS DE TESTE (DML - INSERTS)
-- =================================================================================

-- Limpeza segura para permitir reexecução do script
DELETE FROM logs_auditoria;
DELETE FROM ordens_servico_pecas;
DELETE FROM ordens_servico_servicos;
DELETE FROM ordens_servico;
DELETE FROM pecas_compras;
DELETE FROM compras;
DELETE FROM servicos;
DELETE FROM pecas;
DELETE FROM veiculos;
DELETE FROM mecanicos;
DELETE FROM funcionarios;
DELETE FROM clientes;
DELETE FROM pessoas;
DELETE FROM usuarios;
GO

-- 2.0 USUÁRIOS DO SISTEMA (3 PERFIS DIFERENTES: ADMIN, ATENDENTE e MECANICO)
SET IDENTITY_INSERT usuarios ON;
INSERT INTO usuarios (codigo, username, password, nome_completo, email, perfil, dica_senha, ativo) VALUES
(1, 'admin', '123', 'Administrador Geral (Gerente)', 'admin@henmaravi.com', 'ADMIN', 'Sequência numérica de 1 a 3', 1),
(2, 'mecanico', '123', 'Kleber Machado (Mecânico)', 'mecanico@henmaravi.com', 'MECANICO', 'Sequência numérica de 1 a 3', 1),
(3, 'atendente', '123', 'Beatriz Silva (Operacional)', 'beatriz@henmaravi.com', 'ATENDENTE', 'Sequência numérica de 1 a 3', 1);
SET IDENTITY_INSERT usuarios OFF;
GO

-- 2.1 PESSOAS PARA CLIENTES (IDs de 1 a 10)
SET IDENTITY_INSERT pessoas ON;
INSERT INTO pessoas (codigo, cpf, nome, telefone, cep, email) VALUES 
(1, '11111111111', 'João Silva', '(11) 99999-1111', '01001000', 'joao@email.com'),
(2, '22222222222', 'Maria Oliveira', '(11) 98888-2222', '02002000', 'maria@email.com'),
(3, '33333333333', 'Carlos Mendes', '(11) 97777-3333', '03003000', 'carlos@email.com'),
(4, '44444444444', 'Ana Souza', '(11) 96666-4444', '04004000', 'ana@email.com'),
(5, '55555555555', 'Pedro Santos', '(11) 95555-5555', '05005000', 'pedro@email.com'),
(6, '66666666666', 'Lucia Lima', '(11) 94444-6666', '06006000', 'lucia@email.com'),
(7, '77777777777', 'Roberto Costa', '(11) 93333-7777', '07007000', 'roberto@email.com'),
(8, '88888888888', 'Fernanda Gomes', '(11) 92222-8888', '08008000', 'fernanda@email.com'),
(9, '99999999999', 'Marcos Ferreira', '(11) 91111-9999', '09009000', 'marcos@email.com'),
(10, '00000000000', 'Juliana Rocha', '(11) 90000-0000', '10010000', 'juliana@email.com');
SET IDENTITY_INSERT pessoas OFF;

INSERT INTO clientes (pessoas_codigo) VALUES 
(1), (2), (3), (4), (5), (6), (7), (8), (9), (10);

-- 2.2 PESSOAS PARA FUNCIONARIOS (IDs de 11 a 20)
SET IDENTITY_INSERT pessoas ON;
INSERT INTO pessoas (codigo, cpf, nome, telefone, cep, email) VALUES 
(11, '12312312311', 'Armando Souza', '(11) 91234-1111', '01001001', 'armando@email.com'),
(12, '12312312322', 'Beatriz Silva', '(11) 91234-2222', '02002002', 'beatriz@email.com'),
(13, '12312312333', 'Caio Ribeiro', '(11) 91234-3333', '03003003', 'caio@email.com'),
(14, '12312312344', 'Daniel Alves', '(11) 91234-4444', '04004004', 'daniel@email.com'),
(15, '12312312355', 'Elaine Costa', '(11) 91234-5555', '05005005', 'elaine@email.com'),
(16, '12312312366', 'Fabio Junior', '(11) 91234-6666', '06006006', 'fabio@email.com'),
(17, '12312312377', 'Gabriel Lima', '(11) 91234-7777', '07007007', 'gabriel@email.com'),
(18, '12312312388', 'Helena Moraes', '(11) 91234-8888', '08008008', 'helena@email.com'),
(19, '12312312399', 'Igor Santos', '(11) 91234-9999', '09009009', 'igor@email.com'),
(20, '12312312300', 'Joana Darc', '(11) 91234-0000', '10010010', 'joana@email.com');
SET IDENTITY_INSERT pessoas OFF;

INSERT INTO funcionarios (salario, pessoas_codigo) VALUES 
(5000.00, 11), (2000.00, 12), (2000.00, 13), (2200.00, 14), (2000.00, 15),
(3500.00, 16), (1800.00, 17), (1900.00, 18), (2500.00, 19), (1500.00, 20);

-- 2.3 PESSOAS PARA MECANICOS (IDs de 21 a 30)
SET IDENTITY_INSERT pessoas ON;
INSERT INTO pessoas (codigo, cpf, nome, telefone, cep, email) VALUES 
(21, '32132132111', 'Kleber Machado', '(11) 93210-1111', '01001011', 'kleber@email.com'),
(22, '32132132122', 'Leandro Borges', '(11) 93210-2222', '02002022', 'leandro@email.com'),
(23, '32132132133', 'Mario Sergio', '(11) 93210-3333', '03003033', 'mario@email.com'),
(24, '32132132144', 'Norberto Silva', '(11) 93210-4444', '04004044', 'norberto@email.com'),
(25, '32132132155', 'Osvaldo Cruz', '(11) 93210-5555', '05005055', 'osvaldo@email.com'),
(26, '32132132166', 'Paulo Nunes', '(11) 93210-6666', '06006066', 'paulo@email.com'),
(27, '32132132177', 'Rafael Dias', '(11) 93210-7777', '07007077', 'rafael@email.com'),
(28, '32132132188', 'Samuel Costa', '(11) 93210-8888', '08008088', 'samuel@email.com'),
(29, '32132132199', 'Thiago Neves', '(11) 93210-9999', '09009099', 'thiago@email.com'),
(30, '32132132100', 'Ulisses Guimaraes', '(11) 93210-0000', '10010100', 'ulisses@email.com');
SET IDENTITY_INSERT pessoas OFF;

INSERT INTO mecanicos (comissao, pessoas_codigo) VALUES 
(10.00, 21), (15.00, 22), (12.00, 23),
(10.00, 24), (20.00, 25), (15.00, 26),
(10.00, 27), (12.00, 28), (10.00, 29),
(18.00, 30);

-- 2.4 VEICULOS (10 registros)
SET IDENTITY_INSERT veiculos ON;
INSERT INTO veiculos (codigo, descricao, placa, preco) VALUES 
(1, 'Honda Civic Sedan Prata', 'ABC1234', 85000.00),
(2, 'Toyota Corolla XEI Preto', 'DEF5678', 120000.00),
(3, 'Fiat Strada Freedom Branca', 'GHI9012', 90000.00),
(4, 'VW Gol 1.0 Flex Vermelho', 'JKL3456', 45000.00),
(5, 'Hyundai HB20 Comfort Azul', 'MNO7890', 70000.00),
(6, 'Jeep Renegade Sport Verde', 'PQR1234', 95000.00),
(7, 'Chevrolet Onix LT Prata', 'STU5678', 75000.00),
(8, 'Ford Ka SE Hatch Branco', 'VWX9012', 50000.00),
(9, 'Renault Logan Expression', 'YZA3456', 55000.00),
(10, 'VW Nivus Highline Cinza', 'BCD7890', 130000.00);
SET IDENTITY_INSERT veiculos OFF;

-- 2.5 PECAS (10 registros)
SET IDENTITY_INSERT pecas ON;
INSERT INTO pecas (codigo, descricao, estoque, nome, numero, preco) VALUES 
(1, 'Óleo de motor para troca', 50, 'Óleo Sintético 5W30', 'OL-001', 45.90),
(2, 'Filtro para proteção', 30, 'Filtro de Óleo Bosch', 'FO-002', 25.50),
(3, 'Para freios a disco', 20, 'Pastilha de Freio', 'PF-003', 120.00),
(4, 'Amortecedor a gás', 10, 'Amortecedor Dianteiro', 'AM-004', 350.00),
(5, 'Bateria 12V selada', 15, 'Bateria Moura 60Ah', 'BA-005', 450.00),
(6, 'Vela resistiva', 100, 'Vela de Ignição NGK', 'VL-006', 20.00),
(7, 'Correia em V', 25, 'Correia Dentada Gates', 'CD-007', 85.00),
(8, 'Filtro motor', 40, 'Filtro de Ar Fram', 'FA-008', 35.00),
(9, 'Palheta de borracha', 60, 'Palheta Parabrisa', 'PL-009', 40.00),
(10, 'Lâmpada halógena', 80, 'Lâmpada H7 Philips', 'LP-010', 55.00);
SET IDENTITY_INSERT pecas OFF;

-- 2.6 SERVICOS (10 registros)
SET IDENTITY_INSERT servicos ON;
INSERT INTO servicos (codigo_servico, descricao, preco) VALUES 
(1, 'Troca de Óleo e Filtro', 50.00),
(2, 'Alinhamento e Balanceamento', 120.00),
(3, 'Substituição de Pastilhas', 80.00),
(4, 'Troca de Amortecedores', 200.00),
(5, 'Limpeza de Bico Injetor', 150.00),
(6, 'Revisão Elétrica', 100.00),
(7, 'Troca de Correia Dentada', 250.00),
(8, 'Higienização de Ar Condicionado', 130.00),
(9, 'Regulagem de Farol', 40.00),
(10, 'Diagnóstico Computadorizado', 90.00);
SET IDENTITY_INSERT servicos OFF;

-- 2.7 COMPRAS (10 registros)
SET IDENTITY_INSERT compras ON;
INSERT INTO compras (codigo, data_compra, valor_total, funcionarios_codigo) VALUES 
(1, '2026-06-01 10:00:00', 450.00, 11),
(2, '2026-06-01 14:30:00', 120.00, 12),
(3, '2026-06-02 09:15:00', 350.00, 13),
(4, '2026-06-02 16:45:00', 80.00, 14),
(5, '2026-06-03 11:20:00', 150.00, 15),
(6, '2026-06-03 13:10:00', 250.00, 16),
(7, '2026-06-04 10:05:00', 50.00, 17),
(8, '2026-06-04 15:50:00', 90.00, 18),
(9, '2026-06-05 08:40:00', 130.00, 19),
(10, '2026-06-05 17:00:00', 200.00, 20);
SET IDENTITY_INSERT compras OFF;

-- 2.8 PECAS_COMPRAS (10 registros)
INSERT INTO pecas_compras (preco_unitario, qtd, compras_codigo, pecas_codigo) VALUES 
(45.00, 10, 1, 1),
(120.00, 1, 2, 3),
(350.00, 1, 3, 4),
(40.00, 2, 4, 9),
(15.00, 10, 5, 6),
(250.00, 1, 6, 7),
(25.00, 2, 7, 2),
(45.00, 2, 8, 1),
(130.00, 1, 9, 8),
(20.00, 10, 10, 6);

-- 2.9 ORDENS_SERVICO (10 registros)
SET IDENTITY_INSERT ordens_servico ON;
INSERT INTO ordens_servico (codigo, data_abretura, status, clientes_codigo, funcionarios_codigo, mecanicos_codigo, veiculos_codigo) VALUES 
(1, '2026-06-01 08:00:00', 'Concluída', 1, 11, 21, 1),
(2, '2026-06-01 09:30:00', 'Concluída', 2, 12, 22, 2),
(3, '2026-06-02 10:15:00', 'Em Andamento', 3, 13, 23, 3),
(4, '2026-06-02 14:00:00', 'Aberta', 4, 14, 24, 4),
(5, '2026-06-03 11:45:00', 'Aguardando Peça', 5, 15, 25, 5),
(6, '2026-06-03 15:20:00', 'Em Andamento', 6, 16, 26, 6),
(7, '2026-06-04 09:10:00', 'Concluída', 7, 17, 27, 7),
(8, '2026-06-04 13:40:00', 'Aberta', 8, 18, 28, 8),
(9, '2026-06-05 10:05:00', 'Concluída', 9, 19, 29, 9),
(10, '2026-06-05 16:30:00', 'Em Andamento', 10, 20, 30, 10);
SET IDENTITY_INSERT ordens_servico OFF;

-- 2.10 ORDENS_SERVICO_PECAS E ORDENS_SERVICO_SERVICOS (10 + 10)
INSERT INTO ordens_servico_pecas (preco, qtd, ordens_servico_codigo, pecas_codigo) VALUES 
(45.90, 4, 1, 1), (25.50, 1, 1, 2), (350.00, 2, 2, 4), (20.00, 4, 5, 6), (120.00, 1, 6, 3),
(45.90, 4, 7, 1), (25.50, 1, 7, 2), (85.00, 1, 4, 7), (35.00, 1, 4, 8), (450.00, 1, 3, 5);

INSERT INTO ordens_servico_servicos (preco, qtd, ordens_servico_codigo, servicos_codigo) VALUES 
(50.00, 1, 1, 1), (200.00, 1, 2, 4), (120.00, 1, 2, 2), (150.00, 1, 5, 5), (80.00, 1, 6, 3),
(50.00, 1, 7, 1), (250.00, 1, 4, 7), (130.00, 1, 8, 8), (90.00, 1, 5, 10), (100.00, 1, 3, 6);
GO


-- =================================================================================
-- 3. TRÊS FUNÇÕES (FUNCTIONS) - ESCALAR, TABELA E VARIÁVEL TIPO TABELA (ITEM 5.2)
-- =================================================================================

-- 3.1 FUNCTION 1 (RETORNA VARIÁVEL ESCALAR): Calcula o valor total de uma O.S.
CREATE OR ALTER FUNCTION dbo.fn_CalcularTotalOS (@os_codigo INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @total_pecas DECIMAL(10,2);
    DECLARE @total_servicos DECIMAL(10,2);
    DECLARE @valor_final DECIMAL(10,2);

    SELECT @total_pecas = ISNULL(SUM(preco * qtd), 0)
    FROM ordens_servico_pecas
    WHERE ordens_servico_codigo = @os_codigo;

    SELECT @total_servicos = ISNULL(SUM(preco * qtd), 0)
    FROM ordens_servico_servicos
    WHERE ordens_servico_codigo = @os_codigo;

    SET @valor_final = @total_pecas + @total_servicos;
    RETURN @valor_final;
END;
GO

-- 3.2 FUNCTION 2 (RETORNA UMA TABELA - INLINE TABLE-VALUED FUNCTION):
-- Retorna o histórico de Ordens de Serviço de um determinado cliente
CREATE OR ALTER FUNCTION dbo.fn_BuscarOSPorCliente (@cliente_codigo INT)
RETURNS TABLE
AS
RETURN (
    SELECT 
        os.codigo AS os_codigo,
        os.data_abretura AS data_abertura,
        os.status,
        v.placa,
        v.descricao AS veiculo,
        p_mec.nome AS mecanico,
        dbo.fn_CalcularTotalOS(os.codigo) AS valor_total
    FROM ordens_servico os
    INNER JOIN veiculos v ON os.veiculos_codigo = v.codigo
    INNER JOIN pessoas p_mec ON os.mecanicos_codigo = p_mec.codigo
    WHERE os.clientes_codigo = @cliente_codigo
);
GO

-- 3.3 FUNCTION 3 (RETORNA UMA VARIÁVEL TIPO TABELA - MULTI-STATEMENT TABLE-VALUED FUNCTION):
-- Declara e popula a variável @TabelaComissao filtrando pelo status da O.S.
CREATE OR ALTER FUNCTION dbo.fn_RelatorioComissaoPorStatus (@status VARCHAR(50))
RETURNS @TabelaComissao TABLE (
    mecanico_codigo INT,
    nome_mecanico VARCHAR(150),
    qtd_os INT,
    valor_servicos DECIMAL(10,2),
    taxa_comissao DECIMAL(10,2),
    comissao_calculada DECIMAL(10,2),
    classificacao VARCHAR(50)
)
AS
BEGIN
    INSERT INTO @TabelaComissao (
        mecanico_codigo, nome_mecanico, qtd_os, valor_servicos, taxa_comissao, comissao_calculada, classificacao
    )
    SELECT 
        m.pessoas_codigo,
        p.nome,
        COUNT(DISTINCT os.codigo) AS qtd_os,
        ISNULL(SUM(oss.preco * oss.qtd), 0) AS valor_servicos,
        m.comissao AS taxa_comissao,
        ROUND(ISNULL(SUM(oss.preco * oss.qtd), 0) * (m.comissao / 100.0), 2) AS comissao_calculada,
        CASE 
            WHEN ISNULL(SUM(oss.preco * oss.qtd), 0) >= 200 THEN 'ALTA PERFORMANCE'
            WHEN ISNULL(SUM(oss.preco * oss.qtd), 0) > 0 THEN 'REGULAR'
            ELSE 'SEM MOVIMENTO NO STATUS'
        END AS classificacao
    FROM mecanicos m
    INNER JOIN pessoas p ON m.pessoas_codigo = p.codigo
    LEFT JOIN ordens_servico os ON os.mecanicos_codigo = m.pessoas_codigo AND os.status = @status
    LEFT JOIN ordens_servico_servicos oss ON oss.ordens_servico_codigo = os.codigo
    GROUP BY m.pessoas_codigo, p.nome, m.comissao;

    RETURN;
END;
GO


-- =================================================================================
-- 4. TRÊS CONSULTAS COMPLEXAS POR MEIO DE VIEWS (ITEM 5.2)
-- =================================================================================

-- 4.1 VIEW 1: Resumo Completo de Ordens de Serviço (Múltiplos JOINs + Subqueries Financeiras)
CREATE OR ALTER VIEW dbo.vw_ResumoOrdensServico AS
SELECT 
    os.codigo AS os_codigo,
    os.data_abretura AS data_abertura,
    os.status,
    p_cli.nome AS nome_cliente,
    p_cli.cpf AS cpf_cliente,
    v.placa AS placa_veiculo,
    v.descricao AS descricao_veiculo,
    p_mec.nome AS nome_mecanico,
    p_fun.nome AS nome_funcionario,
    ISNULL((SELECT SUM(osp.preco * osp.qtd) FROM ordens_servico_pecas osp WHERE osp.ordens_servico_codigo = os.codigo), 0) AS total_pecas,
    ISNULL((SELECT SUM(oss.preco * oss.qtd) FROM ordens_servico_servicos oss WHERE oss.ordens_servico_codigo = os.codigo), 0) AS total_servicos,
    dbo.fn_CalcularTotalOS(os.codigo) AS valor_total_os
FROM ordens_servico os
INNER JOIN pessoas p_cli ON os.clientes_codigo = p_cli.codigo
INNER JOIN pessoas p_mec ON os.mecanicos_codigo = p_mec.codigo
INNER JOIN pessoas p_fun ON os.funcionarios_codigo = p_fun.codigo
INNER JOIN veiculos v ON os.veiculos_codigo = v.codigo;
GO

-- 4.2 VIEW 2: Desempenho e Comissionamento dos Mecânicos (JOIN + GROUP BY + CASE + SUM)
CREATE OR ALTER VIEW dbo.vw_DesempenhoMecanicos AS
SELECT 
    m.pessoas_codigo AS mecanico_codigo,
    p.nome AS nome_mecanico,
    m.comissao AS percentual_comissao,
    COUNT(DISTINCT os.codigo) AS total_os_atendidas,
    SUM(CASE WHEN os.status = 'Concluída' THEN 1 ELSE 0 END) AS os_concluidas,
    ISNULL(SUM(oss.preco * oss.qtd), 0) AS receita_servicos_gerada,
    ROUND(ISNULL(SUM(oss.preco * oss.qtd), 0) * (m.comissao / 100.0), 2) AS valor_comissao_estimada
FROM mecanicos m
INNER JOIN pessoas p ON m.pessoas_codigo = p.codigo
LEFT JOIN ordens_servico os ON os.mecanicos_codigo = m.pessoas_codigo
LEFT JOIN ordens_servico_servicos oss ON oss.ordens_servico_codigo = os.codigo
GROUP BY m.pessoas_codigo, p.nome, m.comissao;
GO

-- 4.3 VIEW 3: Análise Financeira e Giro de Estoque de Peças
CREATE OR ALTER VIEW dbo.vw_AnaliseEstoquePecas AS
SELECT 
    pe.codigo AS peca_codigo,
    pe.numero,
    pe.nome,
    pe.preco AS preco_atual,
    pe.estoque AS estoque_atual,
    ROUND(pe.preco * pe.estoque, 2) AS valor_estoque_parado,
    ISNULL((SELECT SUM(pc.qtd) FROM pecas_compras pc WHERE pc.pecas_codigo = pe.codigo), 0) AS total_comprado_historico,
    ISNULL((SELECT SUM(osp.qtd) FROM ordens_servico_pecas osp WHERE osp.pecas_codigo = pe.codigo), 0) AS total_consumido_os,
    CASE 
        WHEN pe.estoque <= 10 THEN 'CRÍTICO'
        WHEN pe.estoque <= 25 THEN 'ALERTA'
        ELSE 'NORMAL'
    END AS situacao_estoque
FROM pecas pe;
GO


-- =================================================================================
-- 5. TRÊS TRIGGERS DISPARADOS POR TRANSAÇÕES DO PROGRAMA JAVA (ITEM 5.2)
-- =================================================================================

-- 5.1 TRIGGER 1: Auditoria Automática de Mudança de Status em Ordem de Serviço
CREATE OR ALTER TRIGGER dbo.trg_AuditoriaStatusOS
ON dbo.ordens_servico
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF UPDATE(status)
    BEGIN
        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        SELECT 
            GETDATE(),
            'ordens_servico',
            'TRIGGER_UPDATE_STATUS',
            CONCAT('O.S. #', i.codigo, ' teve status alterado de [', d.status, '] para [', i.status, '].')
        FROM inserted i
        INNER JOIN deleted d ON i.codigo = d.codigo
        WHERE ISNULL(i.status, '') <> ISNULL(d.status, '');
    END
END;
GO

-- 5.2 TRIGGER 2: Validação de Integridade de Estoque e Auditoria de Peças na O.S.
CREATE OR ALTER TRIGGER dbo.trg_ValidarEAuditarItemOSPeca
ON dbo.ordens_servico_pecas
AFTER INSERT, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Garante no banco que nenhuma peça fique com estoque negativo
    IF EXISTS (SELECT 1 FROM pecas WHERE estoque < 0)
    BEGIN
        RAISERROR('Operação bloqueada pelo Trigger: Estoque da peça não pode ficar negativo.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END

    -- Se foi inserção de peça na O.S.
    IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        SELECT 
            GETDATE(),
            'ordens_servico_pecas',
            'TRIGGER_SAIDA_PECA',
            CONCAT('Saída de ', i.qtd, 'x peça cód. ', i.pecas_codigo, ' vinculada à O.S. #', i.ordens_servico_codigo, ' (Preço Unit: R$ ', i.preco, ').')
        FROM inserted i;
    END

    -- Se foi remoção/estorno de peça da O.S.
    IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
    BEGIN
        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        SELECT 
            GETDATE(),
            'ordens_servico_pecas',
            'TRIGGER_ESTORNO_PECA',
            CONCAT('Estorno de ', d.qtd, 'x peça cód. ', d.pecas_codigo, ' removida da O.S. #', d.ordens_servico_codigo, '.')
        FROM deleted d;
    END
END;
GO

-- 5.3 TRIGGER 3: Recálculo Financeiro e Auditoria em Entrada de Compras
CREATE OR ALTER TRIGGER dbo.trg_AuditoriaItemCompra
ON dbo.pecas_compras
AFTER INSERT, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Recalcula automaticamente o valor_total da compra afetada
    UPDATE c
    SET c.valor_total = ISNULL((
        SELECT SUM(pc.preco_unitario * pc.qtd)
        FROM pecas_compras pc
        WHERE pc.compras_codigo = c.codigo
    ), 0)
    FROM compras c
    WHERE c.codigo IN (
        SELECT compras_codigo FROM inserted
        UNION
        SELECT compras_codigo FROM deleted
    );

    IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        SELECT 
            GETDATE(),
            'pecas_compras',
            'TRIGGER_ENTRADA_ESTOQUE',
            CONCAT('Entrada na Nota de Compra #', i.compras_codigo, ': +', i.qtd, ' un. da peça cód. ', i.pecas_codigo, ' (Custo Unit: R$ ', i.preco_unitario, ').')
        FROM inserted i;
    END
END;
GO


-- =================================================================================
-- 6. TRÊS STORED PROCEDURES COM TRANSAÇÃO PROGRAMADA CHAMADAS PELO JAVA (ITEM 5.2)
-- =================================================================================

-- 6.1 PROCEDURE 1: Finalizar Ordem de Serviço com Validação e Transação
CREATE OR ALTER PROCEDURE dbo.sp_FinalizarOrdemServico
    @os_codigo INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (SELECT 1 FROM ordens_servico WHERE codigo = @os_codigo)
        BEGIN
            ;THROW 50001, 'Ordem de Serviço não encontrada.', 1;
        END

        DECLARE @qtd_itens INT;
        SELECT @qtd_itens = 
            (SELECT COUNT(*) FROM ordens_servico_pecas WHERE ordens_servico_codigo = @os_codigo) +
            (SELECT COUNT(*) FROM ordens_servico_servicos WHERE ordens_servico_codigo = @os_codigo);

        IF @qtd_itens = 0
        BEGIN
            ;THROW 50002, 'Não é permitido concluir uma O.S. sem nenhuma peça ou serviço lançado.', 1;
        END

        UPDATE ordens_servico
        SET status = 'Concluída'
        WHERE codigo = @os_codigo;

        DECLARE @total DECIMAL(10,2) = dbo.fn_CalcularTotalOS(@os_codigo);

        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        VALUES (
            GETDATE(),
            'ordens_servico',
            'SP_FINALIZAR_OS',
            CONCAT('Procedure sp_FinalizarOrdemServico concluiu a O.S. #', @os_codigo, ' com valor total de R$ ', @total, '.')
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        ;THROW;
    END CATCH
END;
GO

-- 6.2 PROCEDURE 2: Reajustar Preço de Catálogo das Peças em Lote com Transação
CREATE OR ALTER PROCEDURE dbo.sp_ReajustarPrecoPecas
    @percentual DECIMAL(5,2)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF @percentual < -50.00 OR @percentual > 100.00
        BEGIN
            ;THROW 50003, 'Percentual de reajuste fora do limite seguro (-50% a +100%).', 1;
        END

        UPDATE pecas
        SET preco = ROUND(preco * (1.0 + (@percentual / 100.0)), 2);

        DECLARE @afetadas INT = @@ROWCOUNT;

        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        VALUES (
            GETDATE(),
            'pecas',
            'SP_REAJUSTE_PRECOS',
            CONCAT('Procedure sp_ReajustarPrecoPecas aplicou ', @percentual, '% em ', @afetadas, ' peças do catálogo.')
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        ;THROW;
    END CATCH
END;
GO

-- 6.3 PROCEDURE 3: Registrar Compra Rápida e Entrada de Estoque em Transação Única
CREATE OR ALTER PROCEDURE dbo.sp_RegistrarCompraRapida
    @funcionario_codigo INT,
    @peca_codigo INT,
    @qtd INT,
    @preco_unitario DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        IF @qtd <= 0 OR @preco_unitario <= 0
        BEGIN
            ;THROW 50004, 'Quantidade e preço unitário devem ser maiores que zero.', 1;
        END

        DECLARE @valor_total DECIMAL(10,2) = ROUND(@qtd * @preco_unitario, 2);

        INSERT INTO compras (data_compra, valor_total, funcionarios_codigo)
        VALUES (GETDATE(), @valor_total, @funcionario_codigo);

        DECLARE @nova_compra_id INT = SCOPE_IDENTITY();

        INSERT INTO pecas_compras (compras_codigo, pecas_codigo, qtd, preco_unitario)
        VALUES (@nova_compra_id, @peca_codigo, @qtd, @preco_unitario);

        UPDATE pecas
        SET estoque = estoque + @qtd
        WHERE codigo = @peca_codigo;

        INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
        VALUES (
            GETDATE(),
            'compras',
            'SP_COMPRA_RAPIDA',
            CONCAT('Procedure sp_RegistrarCompraRapida gerou Compra #', @nova_compra_id, ' (+', @qtd, ' un. da peça #', @peca_codigo, ', Total R$ ', @valor_total, ').')
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        ;THROW;
    END CATCH
END;
GO

-- Registro inicial de auditoria para demonstrar funcionamento imediato
INSERT INTO logs_auditoria (data_evento, tabela_afetada, acao, descricao)
VALUES (GETDATE(), 'HenmaraviDB', 'INICIALIZACAO', 'Banco de dados HenmaraviDB inicializado com Tabelas, Views, Triggers, Functions e Procedures.');
GO

-- =================================================================================
-- 7. SCRIPTS DE BACKUP E RESTORE (ITEM 5.3 - TAMBÉM EXECUTÁVEIS PELA INTERFACE JAVA)
-- =================================================================================
/*
-- COMANDO DE BACKUP COMPLETO:
BACKUP DATABASE HenmaraviDB
TO DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL17.MSSQLSERVER\MSSQL\Backup\HenmaraviDB_Backup.bak'
WITH FORMAT, INIT, NAME = N'HenmaraviDB - Full Backup';
GO

-- COMANDO DE RESTORE COMPLETO:
USE master;
GO
ALTER DATABASE HenmaraviDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
RESTORE DATABASE HenmaraviDB
FROM DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL17.MSSQLSERVER\MSSQL\Backup\HenmaraviDB_Backup.bak'
WITH REPLACE;
ALTER DATABASE HenmaraviDB SET MULTI_USER;
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO
USE HenmaraviDB;
GO
*/
